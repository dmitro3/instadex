from typing import Union

from aiogram.filters import BaseFilter
from aiogram.types import Message, CallbackQuery

from database import models
from loader import get_db
from emoji.core import demojize


class UserFilter(BaseFilter):
    async def __call__(self, tg_object: Union[Message, CallbackQuery]) -> bool:
        usr = tg_object.from_user
        db = get_db()
        user = await db.get(models.User, key={'id': tg_object.from_user.id}, get_type='scalar')
        if not user:
            try:
                await db.insert(
                    models.User,
                    id=usr.id,
                    full_name=demojize(usr.full_name),
                    username=usr.username
                )
            except Exception:
                await db.insert(
                    models.User,
                    id=usr.id,
                    full_name=f'BadName_id{usr.id}',
                    username=usr.username
                )
        else:
            await db.update(
                models.User,
                full_name=demojize(usr.full_name),
                username=usr.username,
                key={'id': usr.id}
            )
        return True
