from contextlib import suppress
from typing import Union

from aiogram.filters import BaseFilter
from aiogram.types import Message, CallbackQuery

from loader import bot
from config import bot_config


class AdminFilter(BaseFilter):
    async def __call__(self, tg_object: Union[Message, CallbackQuery]) -> bool:
        with suppress(Exception):
            if tg_object.chat.id != tg_object.from_user.id:
                chat_member = await bot.get_chat_member(tg_object.chat.id, tg_object.from_user.id)
                return chat_member.status in ['admin', 'administrator', 'creator']
        return tg_object.from_user.id in bot_config.admins
