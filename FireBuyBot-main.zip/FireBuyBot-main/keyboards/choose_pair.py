from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from callback_factories import GSF


def choose_pair_kb(pairs, group_id) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=pair_title,
                    callback_data=GSF(
                        group_id=0,
                        action='p',
                        value=info['pair_address'],
                        dex=info['dex']
                    ).pack()

                )
            ] for pair_title, info in pairs.items()
        ]
        + [
            [
                InlineKeyboardButton(
                    text='Finish',
                    callback_data='finish'
                )
            ]
        ]
    )
    return kb