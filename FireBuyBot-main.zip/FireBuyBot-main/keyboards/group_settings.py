from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from emoji.core import emojize

from callback_factories import GSF
from database import models
from database.models import GroupSettings


def group_settings_kb(gs: GroupSettings) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f'Change Pair: {gs.erctoken.pair_address[:5]}...{gs.erctoken.pair_address[-5:]}',
                    callback_data=GSF(group_id=gs.id, action="ts", value="pair").pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text=f'Minimum Buy: ${gs.min_buy}',
                    callback_data=GSF(group_id=gs.id, action="ts", value="minimum_buy").pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text=f'Step: ${gs.step}',
                    callback_data=GSF(group_id=gs.id, action="ts", value="step").pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text=f'Circulating Supply: {int(int(gs.custom_supply) * 10 ** -gs.erctoken.decimals)}',
                    callback_data=GSF(group_id=gs.id, action="ts", value="custom_supply").pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text=f'Emoji: {emojize(gs.emoji)}',
                    callback_data=GSF(group_id=gs.id, action="ts", value="emoji").pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text=f'Is Paused: {"Yes" if gs.is_paused else "No"}',
                    callback_data=GSF(
                        group_id=gs.id, action="ts", value="is_paused", toggle=False if gs.is_paused else True
                    ).pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text=f'Media Enabled: {"Yes" if gs.media_enabled else "No"}',
                    callback_data=GSF(
                        group_id=gs.id, action="ts", value="media_enabled", toggle=False if gs.media_enabled else True
                    ).pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text=f'Media Image (Click to change/view)',
                    callback_data=GSF(group_id=gs.id, action="ts", value="media").pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text=f'Media Threshold: ${gs.media_threshold}',
                    callback_data=GSF(group_id=gs.id, action="ts", value="media_threshold").pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text='Finish',
                    callback_data='finish'
                )
            ]
        ]
    )
    return kb