from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from callback_factories import BSF
from database import models


def admin_settings_kb(gs: models.GlobalSettings) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f'Turn ON ✅' if gs.is_on else 'Turn OFF ❌',
                    callback_data=BSF(action="turn_bot", value='off' if gs.is_on else 'on', toggle=True).pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text=f'Set new Ad 💸',
                    callback_data=BSF(action='set_ad').pack()
                )
            ]
        ]
    )
    return kb