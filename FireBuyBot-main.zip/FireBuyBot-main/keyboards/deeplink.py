from typing import Union

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def get_deeplink(link: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text='Click me!',
                    url=link
                )
            ]
        ]
    )
    return kb
