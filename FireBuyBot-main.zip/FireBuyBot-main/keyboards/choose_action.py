from typing import Union

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from callback_factories import GSF


def choose_action_kb(group_id: Union[int, str]) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text='Add a New Token',
                    callback_data=GSF(
                        group_id=group_id,
                        action='replace_token'
                    ).pack()
                )
            ],
            [
                InlineKeyboardButton(
                    text='Change Token Settings',
                    callback_data=GSF(
                        group_id=group_id,
                        action='token_settings'
                    ).pack()
                )
            ]
        ]
    )
    return kb