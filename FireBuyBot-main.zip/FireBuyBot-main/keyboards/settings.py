from aiogram.types import ForceReply


def settings_kb(placeholder: str):
    placeholder_dict = {
        "minimum_buy": "enter a new minimum buy in $(or type 'cancel' to cancel)",
        "step": "enter a new step per emoji in $(or type 'cancel' to cancel)",
        "custom_supply": "enter a new circulating supply (excluding burn)(or type 'cancel' to cancel)",
        "emoji": "enter a new emoji to be shown in posts(or type 'cancel' to cancel)",
        "media": "send a new media (photo/gif <5mb) to be shown in posts(or type 'cancel' to cancel)",
        "media_threshold": "enter a new minimum buy amount for the media to be attached to"
                           " post(or type 'cancel' to cancel)",

    }
    kb = ForceReply(input_field_placeholder=f"Please {placeholder_dict[placeholder]}")
    return kb
