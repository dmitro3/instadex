from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def finish_kb(extra_buttons: [InlineKeyboardButton] = None) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text='Finish',
                    callback_data='finish'
                )
            ],
            [*extra_buttons] if extra_buttons else []
        ]
    )
    return kb