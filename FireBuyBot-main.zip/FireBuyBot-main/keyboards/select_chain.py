from typing import List

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from callback_factories import GSF
from database.models import Blockchain


def select_chain_kb(blockchains: List[Blockchain], group_id) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f'{blockchain.name}',
                    callback_data=GSF(
                        group_id=group_id,
                        action='c',
                        value=blockchain.id
                    ).pack()

                )
            ] for blockchain in blockchains
        ]
        + [
            [
                InlineKeyboardButton(
                    text='Finish',
                    callback_data='finish'
                )
            ]
        ]
    )
