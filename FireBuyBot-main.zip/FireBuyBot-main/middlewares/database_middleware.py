from typing import Callable, Dict, Any, Awaitable, Union

from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery

import database
from config import bot_config, db_config


class DBMiddleware(BaseMiddleware):
    async def __call__(
            self,
            handler: Callable[[Union[Message, CallbackQuery], Dict[str, Any]], Awaitable[Any]],
            event: Union[Message, CallbackQuery],
            data: Dict[str, Any]
    ) -> Any:
        data['db'] = database.Client(
            host=db_config.host,
            username=db_config.username,
            password=db_config.password,
            name=bot_config.project)

        return await handler(event, data)