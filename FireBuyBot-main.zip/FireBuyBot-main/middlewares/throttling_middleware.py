import datetime
from typing import Any, Awaitable, Callable, Dict

import asyncio
from aiogram import BaseMiddleware
from aiogram.dispatcher.flags import get_flag
from aiogram.types import Message
from cachetools import TTLCache


class ThrottlingMiddleware(BaseMiddleware):
    caches = {
        "price": TTLCache(maxsize=10_000, ttl=30)
    }

    async def __call__(
            self,
            handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]],
            event: Message,
            data: Dict[str, Any],
    ) -> Any:
        throttling_key = get_flag(data, "throttling_key")
        if throttling_key is not None and throttling_key in self.caches:
            if event.chat.id in self.caches[throttling_key]:
                time_left = self.caches[throttling_key][event.chat.id] - datetime.datetime.utcnow()
                time_left = int(time_left.total_seconds() + self.caches[throttling_key].ttl)
                await event.delete()
                m = await event.answer(f'Next /price call is available in {time_left} seconds')
                await asyncio.sleep(5)
                await m.delete()
                return
            else:
                self.caches[throttling_key][event.chat.id] = datetime.datetime.utcnow()
        return await handler(event, data)