from typing import Union, Optional
from aiogram.filters.callback_data import CallbackData


class BSF(CallbackData, prefix="bs"):
    action: str
    value: Optional[Union[int, str]]
    toggle: Optional[bool]
