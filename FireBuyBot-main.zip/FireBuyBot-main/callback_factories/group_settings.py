from typing import Union, Optional
from aiogram.filters.callback_data import CallbackData


class GSF(CallbackData, prefix="z"):
    group_id: Union[int, str]
    action: str
    value: Optional[Union[int, str]]
    dex: Optional[Union[int, str]]
    toggle: Optional[bool]
