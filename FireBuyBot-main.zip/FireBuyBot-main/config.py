from dataclasses import dataclass


@dataclass
class BotConfig:
    token: str
    project: str
    admins: list
    group: int


@dataclass
class DBConfig:
    host: str
    username: str
    password: str


db_config = DBConfig(
    host='localhost',
    username='root',
    password='<tDAXfuU7>'
)

bot_config = BotConfig(
    token='6841203243:AAEfVrU0LFCPBktCZE8v_U4ySElN6l8z474',
    project='FireBuyBot',
    admins=[579142036, 1292012819, 1114463444],
    group=579142036
)
