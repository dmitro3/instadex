import asyncio
import datetime
import json
import math
from typing import List

from emoji import emojize
from solders.pubkey import Pubkey

from database import Client
from database.models import (
    GroupSettings, Buy, GlobalSettings,
    ERCToken, ERCTrendingPlace,
    TonToken, TonTrendingPlace,
    SolToken, SolTrendingPlace, Blockchain
)
from loader import bot, get_db
from config import bot_config
from sol_parser import TransactionParser

from aiogram.types import BufferedInputFile, InlineKeyboardMarkup, InlineKeyboardButton


async def check_posts(db: Client):
    while True:
        # MATIC SWAP LINK https://quickswap.exchange/#/swap?currency0=ETH&currency1=0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359&swapIndex=0
        try:
            new_buys = await db.get(Buy, key={'is_posted': False}, get_type='scalars', limit=100, order_by=Buy.created_at.desc())
            for buy in new_buys:
                if buy.created_at + datetime.timedelta(minutes=5) < datetime.datetime.now():
                    await db.update(Buy, key={'tx_hash': buy.tx_hash}, is_posted=True)
                    continue
                wallet_value = 0

                if buy.blockchain == 'ton':
                    token: TonToken = await db.get(TonToken, key={'address': buy.token_address})
                    is_trending: TonTrendingPlace = await db.get(
                        TonTrendingPlace, key={'token_address': buy.token_address, 'is_active': True}
                    )
                    extra = f'🎖 | <a href="https://t.me/{token.blockchain.trending_channel_username}/{token.blockchain.trending_channel_id}">TRENDING #{is_trending.place + 1}</a>' if is_trending else ''
                    if not token:
                        await db.update(Buy, key={'tx_hash': buy.tx_hash}, is_posted=True)
                        continue
                    txlink = f'https://tonviewer.com/transaction/{buy.tx_hash}'
                    chartlink = f'https://www.geckoterminal.com/ton/pools/{buy.token_address}'
                    chartlink2 = f'https://www.geckoterminal.com/ton/pools/{buy.token_address}'
                    buyerlink = f'https://tonviewer.com/{buy.signer}'
                    trending_link = 'https://t.me/tontrending'
                    buy_link = f'https://app.ston.fi/swap?outputCurrency={buy.token_address}&chartVisible=false'
                    groups: List[GroupSettings] = await db.get(
                        GroupSettings,
                        key={'ton_token_address': buy.token_address},
                        order_by=GroupSettings.members_count.desc(),
                        get_type='scalars'
                    )
                    if not groups:
                        await db.update(Buy, key={'tx_hash': buy.tx_hash}, is_posted=True)
                        continue

                    main_group = groups[0]

                elif buy.blockchain == 'sol':
                    token: SolToken = await db.get(SolToken, key={'address': buy.token_address})
                    is_trending: SolTrendingPlace = await db.get(
                        SolTrendingPlace, key={'token_address': buy.token_address, 'is_active': True}
                    )
                    extra = f'🎖 | <a href="https://t.me/{token.blockchain.trending_channel_username}/{token.blockchain.trending_channel_id}">TRENDING #{token.trending_place}</a>' if token.trending_place else ''
                    txlink = f'https://solscan.io/tx/{buy.tx_hash}'
                    chartlink2 = f'https://dexscreener.com/solana/{buy.token_address}'
                    chartlink = f'https://birdeye.so/token/{buy.token_address}?chain=solana'
                    buyerlink = f'https://solscan.io/account/{buy.signer}'
                    trending_link = 'https://t.me/SOL_TRENDING'
                    buy_link = f'https://raydium.io/swap/?inputCurrency=sol&outputCurrency={buy.token_address}&fixed=in'

                    groups: List[GroupSettings] = await db.get(
                        GroupSettings,
                        key={'token_address': buy.token_address},
                        order_by=GroupSettings.members_count.desc(),
                        get_type='scalars'
                    )
                    if not groups:
                        await db.update(Buy, key={'tx_hash': buy.tx_hash}, is_posted=True)
                        continue
                    main_group = groups[0]
                    try:
                        wallet_value = truncate(await get_sol_usd_balance(buy.signer), 2)
                    except Exception:
                        wallet_value = '0'
                else:
                    blockchain: Blockchain = await db.get(Blockchain, key={'shortname': buy.blockchain})
                    token: ERCToken = await db.get(ERCToken, key={'address': buy.token_address, 'blockchain_id': blockchain.id})
                    is_trending: ERCTrendingPlace = await db.get(
                        ERCTrendingPlace, key={'erc_token_id': token.id, 'is_active': True, 'blockchain_id': blockchain.id}
                    )
                    extra = f'🎖 | <a href="https://t.me/{blockchain.trending_channel_username}/{blockchain.trending_channel_id}">TRENDING #{token.trending_place}</a>' if token.trending_place else ''
                    txlink = f'{blockchain.explorer}/tx/{buy.tx_hash}'
                    chartlink = f'https://dexscreener.com/{blockchain.name.lower()}/{token.pair_address}'
                    buyerlink = f'{blockchain.explorer}/address/{buy.signer}'
                    trending_link = f'https://t.me/{blockchain.trending_channel_username}'
                    buy_link = f'{token.dex.url}?inputCurrency={blockchain.native_symbol.lower()}&outputCurrency={buy.token_address}' if blockchain.native_symbol != 'MATIC' else f'https://quickswap.exchange/#/swap?currency0=ETH&currency1={buy.token_address}&swapIndex=0'
                    pcslink = f'{token.dex.url}/swap?outputCurrency={token.address}'

                    groups: List[GroupSettings] = await db.get(
                        GroupSettings,
                        key={'erctoken_id': token.id},
                        order_by=GroupSettings.members_count.desc(),
                        get_type='scalars'
                    )
                    if not groups:
                        await db.update(Buy, key={'tx_hash': buy.tx_hash}, is_posted=True)
                        print('not groups!')
                        continue
                    main_group = groups[0]

                _g = None
                await db.update(Buy, key={'tx_hash': buy.tx_hash}, is_posted=True)
                # wallet_value = truncate((await get_sol_usd_balance(buy.signer) + await get_stables_balance(buy.signer)), 2)

                for g in groups:
                    if g.min_buy > int(buy.usd_amount):
                        continue
                    weight = emojize(g.emoji * (int(buy.usd_amount // g.step) + 1) if not buy.is_whale else "🐋" * (
                            int(buy.usd_amount // g.step) + 1))
                    amt = f'{int(float(buy.token_amount)):,}' if float(buy.token_amount) > 0 else float(
                        buy.token_amount)
                    starter = f'🚀 <b>{emojize(token.name)} Buy!</b>' if not buy.is_whale else f'🚀 <b>{emojize(token.name)} WHALE ALERT! 🚀'
                    sol_thing = f'\n\n🌐 Buyer SOL Value: ${wallet_value}' if buy.blockchain == 'sol' else ''
                    post_text = f'{starter}' \
                                f'\n{weight}' \
                                f'\n💵 ${buy.usd_amount} <b>({buy.paid_amount} {buy.paid_with})</b>' \
                                f'\n🪙 {amt} <b>{emojize(token.symbol)}</b>' \
                                f'\n{emojize(buy.printable_position)}' \
                                f'\n\n🏷️ Price <b>${format_price(buy.price)}</b>' \
                                f'\n📊 MCap <b>${int(buy.market_cap):,}</b>' \
                                f"{sol_thing}" \
                                f'\n\n#️⃣ <a href="{txlink}">TX</a>     <a href="{chartlink}">💫 Chart</a>      🥰 <a href="{buyerlink}">Buyer</a>' \
                                f'\n\n{extra}'
                    post_text = f'<b>{emojize(token.name)} Buy!</b>' \
                           f'\n{weight}' \
                           f'\n\n💲 Spent: <b>{buy.paid_amount} ETH</b> (${buy.usd_amount})' \
                           f'\n\n💰 Got: {int(float(buy.token_amount)):,} <b>{token.symbol}</b>' \
                           f'\n🔄 Buy Position: {emojize(buy.printable_position)}' \
                           f'\n✅ Dex: {token.dex.name.title()}' \
                           f'\n🏷️ Price <b>${format_price(buy.price)}</b>' \
                           f'\n📊 MCap <b>${int(buy.market_cap):,}</b>' \
                           f'\n\n' \
                           f'<a href="{txlink}">TX</a> | <a href="{chartlink}">Chart</a> | <a href="{buyerlink}">Buyer</a> | <a href="{pcslink}">Buy</a>'
                    pic = g.media
                    _g = g
                    settings: GlobalSettings = await db.get(GlobalSettings, key={'id': 1})
                    kb = InlineKeyboardMarkup(
                        inline_keyboard=[
                            [
                                InlineKeyboardButton(
                                    text="💰 BUY NOW",
                                    url=buy_link
                                )
                            ],
                            [] if not settings.next_advert_text else [
                                InlineKeyboardButton(
                                    text=emojize(settings.next_advert_text),
                                    url=settings.next_advert_url
                                )
                            ],
                            [
                                InlineKeyboardButton(
                                    text="🔥 LIVE TRENDING 🔥",
                                    url=trending_link
                                )
                            ]
                        ]
                    )
                    print(g.media_type, g.media_type)

                    await post(db, g, pic, post_text, kb, main_group, _g, buy, blockchain)

                """if (buy.is_whale or int(wallet_value) + int(buy.usd_amount) > 5000) and buy.blockchain == 'sol':
                    token_name = f'<a href="{g.tg_group}">{token.name}</a>'
                    alert_text = "🚨🐋 WHALE ALERT! 🐋🚨" \
                                 f"\n📈 SOL whale just bought {token_name}!" \
                                 f"\n\n💰 Amount: ${buy.usd_amount}" \
                                 f"\n🌐 Wallet Value: ${wallet_value}" \
                                 f"\n📈 <a href='https://solscan.io/account/{buy.signer}'>Wallet Link</a>"
                    await bot.send_message(g.id, alert_text, disable_web_page_preview=True)"""
                if (
                        main_group and buy.is_whale
                ) or (
                        int(wallet_value) + int(buy.usd_amount) > 15000 and buy.blockchain == 'sol'
                ):
                    if buy.usd_amount < 100:
                        continue
                    token_name = f'<a href="{main_group.tg_group}">{emojize(token.name)}</a>'
                    alert_text = "🚨🐋 WHALE ALERT! 🐋🚨" \
                                 f"\n📈 SOL whale just bought {token_name}!" \
                                 f"\n\n💰 Amount: ${buy.usd_amount}" \
                                 f"\n🌐 Wallet Value: ${wallet_value}" \
                                 f"\n📈 <a href='https://solscan.io/account/{buy.signer}'>Wallet Link</a>"
                    await bot.send_message(blockchain.trending_channel_id, alert_text, disable_web_page_preview=True)
        except Exception as e:
            print(e)
            continue


#                await bot.send_message(chat_id=bot_config.admins[0], text=alert_text, disable_web_page_preview=True,)

async def post(db, g, pic, post_text, kb, main_group, _g, buy, blockchain):
    try:
        if g.media_enabled and pic:
            media = BufferedInputFile(file=g.media,
                                      filename='buy.png' if g.media_type == 'photo' else 'buy.mp4')
            if g.media_type == 'photo':
                await bot.send_photo(g.id, photo=media, caption=post_text, reply_markup=kb)
            else:
                await bot.send_animation(g.id, animation=media, caption=post_text, reply_markup=kb)
        else:
            await bot.send_message(g.id, post_text, disable_web_page_preview=True, reply_markup=kb)
    except Exception as e:
        print(e)
        if 'kicked from' in str(e):
            await db.delete(GroupSettings, key={'id': g.id})
        try:
            await bot.send_message(g.id, post_text, disable_web_page_preview=True, reply_markup=kb)
        except Exception:
            pass
        pass
    if g.id == main_group.id:
        await post_to_trending(g, buy, _g, pic, post_text, kb, blockchain)


async def post_to_trending(g: GroupSettings, buy, _g, pic, post_text, kb, blockchain):
    if True:#float(buy.usd_amount) > 1000:
        try:
            if _g and g.media_enabled and pic:
                media = BufferedInputFile(file=g.media,
                                          filename='buy.png' if g.media_type == 'photo' else 'buy.mp4')
                if g.media_type == 'photo':
                    await bot.send_photo(blockchain.trending_channel_id, photo=media, caption=post_text,
                                         reply_markup=kb)
                else:
                    await bot.send_animation(blockchain.trending_channel_id, animation=media, caption=post_text,
                                             reply_markup=kb)
            else:
                await bot.send_message(blockchain.trending_channel_id, post_text, disable_web_page_preview=True,
                                       reply_markup=kb)
        except Exception as e:
            print(e)
            pass
    elif float(buy.usd_amount) > 200 and is_trending:
        try:
            if _g and g.media_enabled and pic:
                media = BufferedInputFile(file=g.media,
                                          filename='buy.png' if g.media_type == 'photo' else 'buy.mp4')
                if g.media_type == 'photo':
                    await bot.send_photo(bot_config.inj_trending_id, photo=media, caption=post_text,
                                         reply_markup=kb)
                else:
                    await bot.send_animation(bot_config.inj_trending_id, animation=media, caption=post_text,
                                             reply_markup=kb)
            else:
                await bot.send_message(bot_config.inj_trending_id, post_text, disable_web_page_preview=True,
                                       reply_markup=kb)
        except Exception as e:
            print(e)
            pass

def format_price(price):
    # Mapping of digits to their subscript counterparts
    zeroes = zero_amt(price)
    if zeroes <= 0:
        return format(price, '.2f')
    exponent_price = str(truncate(price, zeroes + 4) * (10 ** zeroes))
    SUB = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")
    new_price = exponent_price[exponent_price.index(".") + 1:exponent_price.index(".") + 5]
    price = f'0.0{str(zeroes).translate(SUB)}{new_price}'
    return price


def zero_amt(n, q=0):
    if n >= 1:
        return q - 1
    n = n * 10
    return zero_amt(n, q + 1)


def truncate(f, n):
    result = math.floor(f * 10 ** n) / 10 ** n
    if result <= 0:
        result = truncate(f, 5)
    return result


async def get_sol_usd_balance(signer):
    db = get_db()
    parser = TransactionParser('https://api.mainnet-beta.solana.com')
    sol_balance = json.loads(parser.get_balance(Pubkey.from_string(signer)).to_json())
    settings: GlobalSettings = await db.get(GlobalSettings, key={'id': 1})
    return sol_balance['result']['value'] * 10 ** -9 * settings.sol_price


if __name__ == '__main__':
    asyncio.run(check_posts(get_db()))
