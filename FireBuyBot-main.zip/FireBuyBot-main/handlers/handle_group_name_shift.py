from aiogram.types import ContentType, Message

from database import models, Client
from loader import dp
from aiogram import F


@dp.message(F.content_type.in_([ContentType.NEW_CHAT_TITLE]))
async def supergroup_change(m: Message, db: Client):
    new_id = m.migrate_to_chat_id
    old_id = m.chat.id
    print(f'New id: {new_id=}, old id: {old_id=}')
    await db.update(models.GroupSettings, key={'id': m.chat.id}, title=m.new_chat_title)
