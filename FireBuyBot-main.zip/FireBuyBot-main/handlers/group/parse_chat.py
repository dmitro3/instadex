import asyncio

from aiogram.filters import Command
from aiogram.types import Message

from database import Client, models
from emoji.core import demojize
from handlers.routers import group_admin
from loader import plate


@group_admin.message(Command(commands=['parse_chat']))
async def parse_chat(m: Message, db: Client):
    chat = m.chat
    group = await db.get(models.GroupSettings, key={'id': m.chat.id}, get_type='scalar')
    print(group)
    if not group:
        await db.insert(models.GroupSettings, id=m.chat.id, title=demojize(chat.title), username=chat.username)
    else:
        await db.update(models.GroupSettings, key={'id': chat.id}, title=demojize(chat.title), username=chat.username)

    m = await m.answer(plate('group_response'))
    await asyncio.sleep(5)
    await m.delete()

