from aiogram.filters import Command

from aiogram.types import Message
from handlers.routers import group_admin
from keyboards import get_deeplink
from loader import plate, bot


@group_admin.message(Command(commands=['start', 'addToken', 'settings', 'addtoken', 'add_token']))
async def start(m: Message):
    kb = get_deeplink(link=f'https://t.me/{(await bot.get_me()).username}?start={m.chat.id}')
    await m.reply(plate('group_response'), reply_markup=kb)