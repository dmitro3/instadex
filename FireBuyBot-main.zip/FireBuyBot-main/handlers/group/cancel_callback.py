from aiogram import F
from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext
from handlers.routers import group_admin


@group_admin.callback_query(F.data == 'cancel')
async def cancel(c: CallbackQuery, state: FSMContext):
    await state.clear()
    await c.message.delete()
