from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton
from aiogram import F

from callback_factories import GSF
from database import Client, models
from database.models import Blockchain
from handlers.routers import private
from keyboards import finish_kb, choose_pair_kb, select_chain_kb
from loader import plate, get_monitor
from states import InputState


@private.message(StateFilter(InputState.set_token))
async def take_address(m: Message, state: FSMContext, db: Client):
    clock = await m.answer(plate('loading'))
    token = m.text.strip()
    if len(token) != 42 or '0x' not in token:
        kb = finish_kb()
        await clock.edit_text(plate('no_such_token'), reply_markup=kb)
        return
    data = await state.get_data()
    group_id = data['group_id']
    gs = await db.get(models.GroupSettings, get_type='scalar', key={'id': group_id})
    if gs and gs.erctoken and gs.erctoken.address.lower() == token.lower():
        kb = finish_kb(
            extra_buttons=[
                InlineKeyboardButton(
                    text='Change Token Settings',
                    callback_data=GSF(
                        action='token_settings',
                        group_id=group_id
                    ).pack()
                )
            ])
        await clock.edit_text(plate('same_token'), reply_markup=kb)
        return
    blockchain: Blockchain = await db.get(Blockchain, key={'id': data['chain_id']}, relationships=['dexes.blockchain'])
    monitor = get_monitor(blockchain)
    pairs = monitor.check_for_pairs(blockchain, m.text)
    kb = choose_pair_kb(pairs, group_id)
    await state.update_data(pairs_data=pairs)
    await clock.edit_text(plate('select_pair'), reply_markup=kb)

