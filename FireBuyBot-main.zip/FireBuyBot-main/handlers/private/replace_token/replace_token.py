from typing import List

from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery
from aiogram import F

from callback_factories import GSF
from database import Client
from database.models import Blockchain
from handlers.routers import private
from keyboards import select_chain_kb
from loader import plate
from states import InputState


@private.callback_query(GSF.filter(F.action == 'replace_token'))
async def replace_token(c: CallbackQuery, db: Client, callback_data: GSF, state: FSMContext):
    group_id = callback_data.group_id
    await state.set_state(InputState.blockchain)
    await state.update_data(group_id=group_id)
    blockchains: List[Blockchain] = await db.get(Blockchain, get_type='scalars')
    await c.message.edit_text(plate('select_chain'), reply_markup=select_chain_kb(blockchains, group_id))