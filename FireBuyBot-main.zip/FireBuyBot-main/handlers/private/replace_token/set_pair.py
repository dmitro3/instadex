from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery
from aiogram.filters import StateFilter
from aiogram import F

from callback_factories import GSF
from database import Client
from database.models import GroupSettings, ERCToken, Blockchain
from handlers.private.start import private_start_callback
from handlers.routers import private
from loader import plate
from states import InputState


@private.callback_query(GSF.filter(F.action == 'p'), StateFilter(InputState.set_token))
async def request_address(c: CallbackQuery, callback_data: GSF, state: FSMContext, db: Client):
    pair = callback_data.value
    data = await state.get_data()
    group_id = data['group_id']

    pair_data = [v for k, v in data['pairs_data'].items() if data['pairs_data'][k]["pair_address"] == pair][0]
    gs = await db.get(GroupSettings, key={'id': group_id}, get_type='scalar')
    blockchain: Blockchain = await db.get(Blockchain, key={'id': data['chain_id']})
    if blockchain.id <= 5:
        token: ERCToken = await db.get(ERCToken, key={'address': pair_data['token'], 'blockchain_id': blockchain.id})
        print(gs)
        print(data)
        if not token:
            await db.insert(
                ERCToken,
                pair_address=pair,
                blockchain_id=blockchain.id,
                name=pair_data['name'],
                address=pair_data['token'],
                symbol=pair_data['symbol'],
                pair_token=pair_data['pair_token'],
                dex_id=pair_data['dex'],
                decimals=pair_data['decimals']
            )
            token: ERCToken = await db.get(ERCToken, key={'address': pair_data['token'], 'blockchain_id': blockchain.id})
        if not gs:
            await db.insert(
                GroupSettings,
                id=group_id,
                erctoken_id=token.id,
                custom_supply=pair_data['token_supply']
            )
        else:
            await db.update(
                GroupSettings,
                key={'id': group_id},
                erctoken_id=token.id,
                custom_supply=pair_data['token_supply']
            )
        await c.message.edit_text(
            plate('token_set', token=pair_data['token'], liquidity_pool=pair),
            disable_web_page_preview=True
        )
    else:
        pass

    await private_start_callback(c, group_id, new_message=True)
