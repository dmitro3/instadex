from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery
from aiogram import F

from callback_factories import GSF
from handlers.routers import private
from loader import plate
from states import InputState


@private.callback_query(GSF.filter(F.action == 'c'), StateFilter(InputState.blockchain))
async def select_chain(c: CallbackQuery, callback_data: GSF, state: FSMContext):
    chain_id = callback_data.value
    await state.update_data(chain_id=chain_id)
    await state.set_state(InputState.set_token)
    await c.message.edit_text(plate('replace_token'))