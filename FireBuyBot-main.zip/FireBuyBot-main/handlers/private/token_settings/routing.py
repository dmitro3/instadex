from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, BufferedInputFile
from aiogram.filters import StateFilter
from aiogram import F

from callback_factories import GSF
from database import Client, models
from handlers.routers import private
from keyboards import settings_kb, choose_pair_kb
from loader import plate, get_monitor
from states import InputState


@private.callback_query(
    GSF.filter(
        (F.action == 'ts') & (~F.value.in_(['is_paused', 'media_enabled']))
    ),
    StateFilter('*')
)
async def routing(c: CallbackQuery, callback_data: GSF, state: FSMContext, db: Client):
    data = await state.get_data()
    if 'group_id' not in data:
        await c.message.edit_text(plate('start'))
        return
    call = callback_data.value
    await state.set_state(getattr(InputState, call))
    if call == 'media':
        gs: models.GroupSettings = await db.get(
            models.GroupSettings, key={'id': callback_data.group_id}, get_type='scalar'
        )
        if gs.media:
            caption = 'Current media:'
            if gs.media_type == 'photo':
                await c.message.answer_photo(
                    photo=BufferedInputFile(file=gs.media, filename='buy.png'), caption=caption
                )
            else:
                await c.message.answer_animation(
                    animation=BufferedInputFile(file=gs.media, filename='buy.mp4'), caption=caption
                )
    elif call == 'pair':
        await state.set_state(InputState.set_token)
        gs: models.GroupSettings = await db.get(
            models.GroupSettings, key={'id': callback_data.group_id}, get_type='scalar'
        )
        monitor = get_monitor()
        pairs = monitor.check_for_pairs(gs.erctoken)
        kb = choose_pair_kb(pairs, gs.id)

        await state.update_data(pairs_data=pairs)
        await c.message.edit_text(plate('select_pair'), reply_markup=kb)
        return
    await c.message.delete()
    await c.message.answer(plate(call), reply_markup=settings_kb(call))