from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import Message
from emoji.core import demojize

from database import Client, models
from handlers.private.start import private_start_back
from handlers.routers import private
from keyboards import settings_kb
from loader import plate
from states import InputState


@private.message(StateFilter(InputState.emoji))
async def post_emoji(m: Message, state: FSMContext, db: Client):
    kb = settings_kb('emoji')
    new_emoji = m.text.strip()

    if new_emoji == 'cancel':
        await state.clear()
        await m.answer(plate('bye'))
        return

    if ':' in new_emoji:
        await m.answer(
            plate(
                'settings_error',
                error='This is not an emoji. Please send it in "emojized" form, if you sent it like this :smile:'
            ),
            reply_markup=kb)
        return

    data = await state.get_data()
    group_id = data['group_id']
    await db.update(models.GroupSettings, key={'id': group_id}, emoji=demojize(new_emoji))

    await m.answer(plate('settings_success', new_setting=f'emoji to {new_emoji}'))
    await private_start_back(m, group_id)
