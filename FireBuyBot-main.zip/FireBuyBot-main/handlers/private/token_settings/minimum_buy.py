from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import Message

from database import Client, models
from handlers.private.start import private_start_back
from handlers.routers import private
from keyboards import settings_kb
from loader import plate
from states import InputState


@private.message(StateFilter(InputState.minimum_buy))
async def minimum_buy(m: Message, state: FSMContext, db: Client):
    kb = settings_kb('minimum_buy')
    new_min_buy = m.text.strip()
    if new_min_buy == 'cancel':
        await state.clear()
        await m.answer(plate('bye'))
        return
    try:
        new_min_buy = int(new_min_buy)
    except ValueError:
        await m.answer(plate('settings_error', error='Minimum buy has to be an integer number'), reply_markup=kb)
        return
    if new_min_buy < 1:
        await m.answer(plate('settings_error', error='Minimum buy has to be at least 1$'), reply_markup=kb)
        return

    data = await state.get_data()
    group_id = data['group_id']
    await db.update(models.GroupSettings, key={'id': group_id}, min_buy=new_min_buy)

    await m.answer(plate('settings_success', new_setting=f'minimum buy to {new_min_buy}$'))
    await private_start_back(m, group_id)
