from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import Message

from database import Client, models
from handlers.private.start import private_start_back
from handlers.routers import private
from keyboards import settings_kb
from loader import plate
from states import InputState


@private.message(StateFilter(InputState.custom_supply))
async def custom_supply(m: Message, state: FSMContext, db: Client):
    kb = settings_kb('custom_supply')
    custom_supply = m.text.strip()

    if custom_supply == 'cancel':
        await state.clear()
        await m.answer(plate('bye'))
        return
    try:
        new_min_buy = int(custom_supply)
    except ValueError:
        await m.answer(
            plate(
                'settings_error',
                error='Circulating supply an integer number (no need for decimals, put it in full long form)'
            ),
            reply_markup=kb)
        return
    if new_min_buy < 1:
        await m.answer(plate('settings_error', error='Circulating supply has to be at least 1'), reply_markup=kb)
        return

    data = await state.get_data()
    group_id = data['group_id']
    await db.update(models.GroupSettings, key={'id': group_id}, custom_supply=custom_supply)

    await m.answer(plate('settings_success', new_setting=f'circulating supply to {custom_supply}'))
    await private_start_back(m, group_id)
