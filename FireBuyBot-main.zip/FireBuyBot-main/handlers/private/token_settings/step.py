from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import Message

from database import Client, models
from handlers.private.start import private_start_back
from handlers.routers import private
from keyboards import settings_kb
from loader import plate
from states import InputState


@private.message(StateFilter(InputState.step))
async def step(m: Message, state: FSMContext, db: Client):
    kb = settings_kb('step')
    new_step = m.text.strip()
    if new_step == 'cancel':
        await state.clear()
        await m.answer(plate('bye'))
        return
    try:
        new_min_buy = int(new_step)
    except ValueError:
        await m.answer(plate('settings_error', error='Step has to be an integer number'), reply_markup=kb)
        return
    if new_min_buy < 20:
        await m.answer(plate('settings_error', error='Step has to be at least 20$'), reply_markup=kb)
        return

    data = await state.get_data()
    group_id = data['group_id']
    await db.update(models.GroupSettings, key={'id': group_id}, step=new_step)

    await m.answer(plate('settings_success', new_setting=f'step to {new_step}$'))
    await private_start_back(m, group_id)
