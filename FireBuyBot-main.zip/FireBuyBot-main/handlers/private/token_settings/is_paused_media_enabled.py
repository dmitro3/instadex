from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery
from aiogram.filters import StateFilter
from aiogram import F

from callback_factories import GSF
from database import Client, models
from handlers.routers import private
from keyboards import settings_kb
from keyboards.group_settings import group_settings_kb
from loader import plate
from states import InputState


@private.callback_query(
    GSF.filter(
        (F.action == 'ts') & (F.value.in_(['is_paused', 'media_enabled']))
    ),
    StateFilter('*')
)
async def routing(c: CallbackQuery, callback_data: GSF, state: FSMContext, db: Client):
    data = await state.get_data()
    if 'group_id' not in data:
        await c.message.edit_text(plate('start'))
        return
    call = callback_data.value
    await db.toggle(
        models.GroupSettings,
        column=call,
        table_id='id',
        table_id_value=callback_data.group_id,
        new_value=callback_data.toggle
    )
    gs: models.GroupSettings = await db.get(
        models.GroupSettings, key={'id': callback_data.group_id}, get_type='scalar'
    )
    token = gs.erctoken if gs.erctoken else gs.sol_token
    await c.message.edit_text(
        plate("token_settings",
              token_name=token.name,
              token_address=token.address,
              pair_address=token.pair_address),
        reply_markup=group_settings_kb(gs)
    )