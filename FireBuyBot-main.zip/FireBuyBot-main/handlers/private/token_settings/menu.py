from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery
from aiogram.filters import StateFilter
from aiogram import F

from callback_factories import GSF
from database import Client, models
from database.models import GroupSettings
from handlers.routers import private
from keyboards.group_settings import group_settings_kb
from loader import plate


@private.callback_query(GSF.filter(F.action == 'token_settings'), StateFilter('*'))
async def settings_menu(c: CallbackQuery, callback_data: GSF, state: FSMContext, db: Client):
    group_id = callback_data.group_id
    gs: GroupSettings = await db.get(GroupSettings, key={'id': group_id}, get_type='scalar')
    if gs.erctoken is None:
        await c.answer(plate("settings_error", error="No token set!"))
        return
    kb = group_settings_kb(gs)

    await state.update_data(settings=gs)
    await state.update_data(group_id=group_id)

    token = gs.erctoken if gs.erctoken else gs.sol_token
    await c.message.edit_text(
        plate(
            "token_settings",
            token_name=token.name,
            token_address=token.address,
            pair_address=token.pair_address
        ),
        reply_markup=kb
    )