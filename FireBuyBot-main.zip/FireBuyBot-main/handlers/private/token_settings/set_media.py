from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import Message

from database import Client, models
from handlers.private.start import private_start_back
from handlers.routers import private
from keyboards import settings_kb
from loader import plate, bot
from states import InputState


@private.message(StateFilter(InputState.media))
async def media_image(m: Message, state: FSMContext, db: Client):
    kb = settings_kb('media')
    data = await state.get_data()
    group_id = data['group_id']
    if m.content_type == 'photo':
        filesize = m.photo[-1].file_size
        if filesize > 4900000:
            await m.answer(plate('settings_error', error='Media has to be smaller than 5mb'), reply_markup=kb)
            return
        media = await bot.download(m.photo[-1].file_id)
        await db.update(models.GroupSettings, key={'id': group_id}, media=media.read(), media_type=m.content_type)
        await m.answer(plate('settings_success', new_setting=f'media'))
        await private_start_back(m, group_id)
    elif m.content_type == 'animation':
        filesize = m.animation.file_size
        if filesize > 4900000:
            await m.answer(plate('settings_error', error='Media has to be smaller than 5mb'), reply_markup=kb)
            return
        media = await bot.download(m.animation.file_id)
        await db.update(models.GroupSettings, key={'id': group_id}, media=media.read(), media_type=m.content_type)
        await m.answer(plate('settings_success', new_setting=f'media'))
        await private_start_back(m, group_id)
    elif m.content_type == 'video':
        filesize = m.video.file_size
        if filesize > 4900000:
            await m.answer(plate('settings_error', error='Media has to be smaller than 5mb'), reply_markup=kb)
            return
        media = await bot.download(m.video.file_id)
        await db.update(models.GroupSettings, key={'id': group_id}, media=media.read(), media_type='animation')
        await m.answer(plate('settings_success', new_setting=f'media'))
        await private_start_back(m, group_id)
    else:
        if m.text.strip() == 'cancel':
            await state.clear()
            await m.answer(plate('bye'))
            return
        await m.answer(plate('settings_error', error='Media has to be a photo/gif'), reply_markup=kb)
