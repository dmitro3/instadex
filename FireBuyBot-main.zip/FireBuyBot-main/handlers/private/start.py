from typing import Union

from aiogram.filters import Command, CommandObject
from aiogram import F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, FSInputFile
from handlers.routers import private
from keyboards import choose_action_kb
from loader import plate, bot
from states import BuyState


@private.message(Command(commands=['start']), F.chat.id == F.from_user.id)
async def private_start(m: Message, command: CommandObject, state: FSMContext):
    group_id = command.args

    if group_id:
        print(group_id)
        if '-' in str(group_id):
            member = await bot.get_chat_member(group_id, m.from_user.id)
            chat = await bot.get_chat(group_id, m.from_user.id)
            if member.status not in ['creator', 'administrator']:
                await m.answer(plate('start_non_admin', group_name=chat.title))
                return
            kb = choose_action_kb(group_id=group_id)
            await m.answer(plate('start_admin', group_name=chat.title, group_username=chat.username), reply_markup=kb)
        else:
            chain = group_id.replace('buy', '')
            if str(group_id) == 'presale':
                await state.update_data(chain='sol')
                await state.update_data(is_presale=True)
                await state.set_state(BuyState.presale_pool)
                await m.answer_photo(photo=FSInputFile(path='blaze_pool.png', filename='pool.png'),
                                     caption=plate('buy_trending_presale_pool'))
                return
            await state.update_data(chain=chain)
            await state.update_data(is_presale=False)
            await state.set_state(BuyState.token)
            await m.answer(plate('buy_trending_token'))
    else:
        await m.answer(plate('start'))


async def private_start_back(m: Message, group_id: Union[int, str]):
    if group_id:
        member = await bot.get_chat_member(group_id, m.from_user.id)
        chat = await bot.get_chat(group_id, m.from_user.id)
        if member.status not in ['creator', 'administrator']:
            await m.answer(plate('start_non_admin', group_name=chat.title))
            return
        kb = choose_action_kb(group_id=group_id)
        await m.answer(plate('start_admin', group_name=chat.title, group_username=chat.username), reply_markup=kb)
    else:
        await m.answer(plate('start'))


async def private_start_callback(c: CallbackQuery, group_id: Union[int, str], new_message=False):
    if group_id:
        member = await bot.get_chat_member(group_id, c.from_user.id)
        chat = await bot.get_chat(group_id, c.from_user.id)
        if member.status not in ['creator', 'administrator']:
            await c.message.edit_text(plate('start_non_admin', group_name=chat.title))
            return
        kb = choose_action_kb(group_id=group_id)
        await c.message.edit_text(
            plate('start_admin', group_name=chat.title, group_username=chat.username), reply_markup=kb
        )
    else:
        if new_message:
            await c.message.answer(plate('start'))
        else:
            await c.message.edit_text(plate('start'))