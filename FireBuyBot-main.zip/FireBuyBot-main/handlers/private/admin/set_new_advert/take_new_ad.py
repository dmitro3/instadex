from aiogram.fsm.context import FSMContext
from aiogram.types import Message
from aiogram.filters import StateFilter
from database import Client
from handlers.routers import superuser
from keyboards import finish_kb
from loader import plate
from states import InputState


@superuser.message(StateFilter(InputState.new_ad_text))
async def take_new_ad(m: Message, state: FSMContext, db: Client):
    new_ad = m.html_text
    await state.update_data(new_ad_text=new_ad)
    await state.set_state(InputState.new_ad_url)
    kb = finish_kb()
    await m.answer(
        plate("admin_set_new_ad_url", ),
        reply_markup=kb
    )