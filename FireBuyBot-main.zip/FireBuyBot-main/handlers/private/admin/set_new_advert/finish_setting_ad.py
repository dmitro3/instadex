from aiogram.fsm.context import FSMContext
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import StateFilter
from emoji import demojize, emojize

from database import Client, models
from handlers.routers import superuser
from keyboards.admin_settings import admin_settings_kb
from loader import plate
from states import InputState


@superuser.message(StateFilter(InputState.new_ad_url))
async def take_new_ad(m: Message, state: FSMContext, db: Client):
    data = await state.get_data()
    await db.update(models.GlobalSettings, next_advert_text=demojize(data['new_ad_text']), next_advert_url=m.text.strip())
    gs: models.GlobalSettings = await db.get(models.GlobalSettings, get_type='scalar')
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=emojize(gs.next_advert_text),
                    url=gs.next_advert_url
                )
            ]
        ]
    )
    await m.answer(
        plate(
            "settings_success",
            new_setting=f"new ad",
        ),
        reply_markup=kb
    )
    gs: models.GlobalSettings = await db.get(models.GlobalSettings, get_type='scalar')
    kb = admin_settings_kb(gs)

    await m.answer(
        plate(
            "admin_settings",
            status="ON ✅" if gs.is_on else "OFF ❌",
            current_ad=gs.next_advert
        ),
        reply_markup=kb
    )
    await state.clear()