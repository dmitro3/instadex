from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery
from aiogram.filters import StateFilter
from aiogram import F

from callback_factories import BSF
from database import Client
from handlers.routers import superuser
from keyboards import finish_kb
from loader import plate
from states import InputState


@superuser.callback_query(BSF.filter(F.action == 'set_ad'), StateFilter('*'))
async def set_new_ad(c: CallbackQuery, callback_data: BSF, state: FSMContext, db: Client):
    await state.set_state(InputState.new_ad_text)

    kb = finish_kb()
    await c.message.edit_text(
        plate("admin_set_new_ad_text",),
        reply_markup=kb
    )