import datetime

from aiogram.fsm.context import FSMContext
from aiogram.types import Message
from aiogram.filters import Command, CommandObject

from crypto.utils import get_token_data
from database import Client
from database.models import ERCTrendingPlace, ERCToken, SolToken, SolTrendingPlace
from handlers.routers import superuser


@superuser.message(Command(commands=['push']))
async def manual_push(m: Message, state: FSMContext, db: Client, command: CommandObject):
    token, place, hours = command.args.split()
    place = int(place) - 1
    hours = int(hours)
    now = datetime.datetime.now()
    if '0x' in token:
        token: ERCToken = await db.get(ERCToken, key={'address': token})
        if not token:
            await m.reply('Not found. Add the token to the bot first.')
            return
        something_active: ERCTrendingPlace = await db.get(ERCTrendingPlace, key={'place': place, 'is_active': True})
        if something_active:
            await m.reply(f'#{place + 1} is occupied by {something_active.token_address} until {something_active.until}')
            return
        await db.insert(
            ERCTrendingPlace,
            place=place,
            blockchain_id=token.blockchain_id,
            erc_token_id=token.id,
            until=now + datetime.timedelta(hours=hours),
            is_active=True
        )
    else:
        token_data = get_token_data(token=token)

        if not token:
            await db.insert(
                SolToken,
                name=token_data['name'],
                address=m.text.strip(),
                symbol=token_data['symbol'],
                decimals=token_data['decimals'],
                supply=token_data['supply']
            )
            token: SolToken = await db.get(SolToken, key={'address': m.text.strip()})
        something_active: SolTrendingPlace = await db.get(SolTrendingPlace, key={'place': place, 'is_active': True})

        if something_active:
            await m.reply(f'#{place + 1} is occupied by {something_active.token_address} until {something_active.until}')
            return
        await db.insert(
            SolTrendingPlace,
            place=place,
            token_address=token.address,
            until=now + datetime.timedelta(hours=hours),
            is_active=True
        )

    await m.reply(f'Pushed {token.name} to {place + 1} for {hours} hours')
