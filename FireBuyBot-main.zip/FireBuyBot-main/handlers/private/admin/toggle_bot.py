from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery
from aiogram.filters import StateFilter
from aiogram import F
from emoji import emojize

from callback_factories import BSF
from database import Client, models
from handlers.routers import superuser
from keyboards.admin_settings import admin_settings_kb
from loader import plate


@superuser.callback_query(BSF.filter(F.action == 'turn_bot'), StateFilter('*'))
async def toggle_bot(c: CallbackQuery, callback_data: BSF, state: FSMContext, db: Client):
    await db.update(models.GlobalSettings, is_on=True if callback_data.value == 'on' else False)
    gs: models.GlobalSettings = await db.get(models.GlobalSettings, get_type='scalar')
    kb = admin_settings_kb(gs)

    await c.message.edit_text(
        plate(
            "admin_settings",
            status="ON ✅" if not gs.is_on else "OFF ❌",
            current_ad=f'<a href="{gs.next_advert_url}">{emojize(gs.next_advert_text)}</a>'
        ),
        reply_markup=kb
    )