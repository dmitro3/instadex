from aiogram.fsm.context import FSMContext
from aiogram.types import Message
from aiogram.filters import StateFilter, Command
from emoji import emojize

from database import Client, models
from handlers.routers import superuser
from keyboards.admin_settings import admin_settings_kb
from loader import plate


@superuser.message(Command(commands=['admin']), StateFilter('*'))
async def admin_menu(m: Message, state: FSMContext, db: Client):
    gs: models.GlobalSettings = await db.get(models.GlobalSettings, get_type='scalar')
    kb = admin_settings_kb(gs)

    await m.answer(
        plate(
            "admin_settings",
            status="ON ✅" if gs.is_on else "OFF ❌",
            current_ad=f'<a href="{gs.next_advert_url}">{emojize(gs.next_advert_text)}</a>' if gs.next_advert_text else '-'
        ),
        reply_markup=kb
    )