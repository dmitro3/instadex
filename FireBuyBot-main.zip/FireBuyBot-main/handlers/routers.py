from aiogram import Router, F
from filters import AdminFilter, SuperUserFilter


superuser = Router(name='superuser')
superuser.message.filter(SuperUserFilter())
superuser.callback_query.filter(SuperUserFilter())
superuser.message.filter(F.chat.type.in_(['private']))
superuser.callback_query.filter(F.message.chat.type.in_(['private']))

group_admin = Router(name='group_admin')
group_admin.message.filter(AdminFilter())
group_admin.callback_query.filter(AdminFilter())
group_admin.message.filter(F.chat.type.in_(['group', 'supergroup']))
group_admin.callback_query.filter(F.message.chat.type.in_(['group', 'supergroup']))

group_user = Router(name='group_user')
group_user.message.filter(F.chat.type.in_(['group', 'supergroup']))
group_user.callback_query.filter(F.message.chat.type.in_(['group', 'supergroup']))

private = Router(name='private')
private.message.filter(F.chat.type.in_(['private']))
private.callback_query.filter(F.message.chat.type.in_(['private']))