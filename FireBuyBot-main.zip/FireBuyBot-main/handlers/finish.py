from aiogram.types import CallbackQuery
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram import F
from loader import dp, plate


@dp.callback_query(F.data == 'finish', StateFilter('*'))
async def finish_cb(c: CallbackQuery, state: FSMContext):
    await state.clear()
    await c.message.edit_text(plate('bye'))