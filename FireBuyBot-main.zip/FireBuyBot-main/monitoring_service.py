import json
import math
import time
from multiprocessing import Process, Queue
from typing import Dict

import web3
from web3.exceptions import ABIFunctionNotFound

import database
from database.models import Buy, GroupSettings, Blockchain, ERCToken
from config import bot_config
from crypto import core, base_core

from emoji.core import emojize, demojize


class MonitoringService:
    def __init__(self, blockchain: Blockchain):
        self.blockchain = blockchain
        self.old_block = None
        self.post_queue = Queue()
        self.queue = Queue()
        self.requests_count = 0
        self.wrapped_native = blockchain.native_address
        self.USDT = blockchain.usdt
        self.USDC = blockchain.usdc

    @property
    def get_w3(self):
        return core.get_w3(self.blockchain)

    @property
    def db(self):
        return database.Client(
            host='localhost',
            username='root',
            password='<tDAXfuU7>',
            name=bot_config.project)

    @property
    def erc20_abi(self):
        return json.loads(
            '[{"inputs":[{"internalType":"address","name":"manager","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"burn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"burnFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"decimal","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"subtractedValue","type":"uint256"}],"name":"decreaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"addedValue","type":"uint256"}],"name":"increaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"}]'
        )

    @property
    def LP_abi(self):
        return json.loads(
            '[{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Burn","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1","type":"uint256"}],"name":"Mint","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0In","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1In","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount0Out","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1Out","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Swap","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint112","name":"reserve0","type":"uint112"},{"indexed":false,"internalType":"uint112","name":"reserve1","type":"uint112"}],"name":"Sync","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"constant":true,"inputs":[],"name":"DOMAIN_SEPARATOR","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"MINIMUM_LIQUIDITY","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"PERMIT_TYPEHASH","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"burn","outputs":[{"internalType":"uint256","name":"amount0","type":"uint256"},{"internalType":"uint256","name":"amount1","type":"uint256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"factory","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getReserves","outputs":[{"internalType":"uint112","name":"_reserve0","type":"uint112"},{"internalType":"uint112","name":"_reserve1","type":"uint112"},{"internalType":"uint32","name":"_blockTimestampLast","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"_token0","type":"address"},{"internalType":"address","name":"_token1","type":"address"}],"name":"initialize","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"kLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"mint","outputs":[{"internalType":"uint256","name":"liquidity","type":"uint256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"nonces","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"permit","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"price0CumulativeLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"price1CumulativeLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"skim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"uint256","name":"amount0Out","type":"uint256"},{"internalType":"uint256","name":"amount1Out","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"swap","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"sync","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"token0","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"token1","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"}]')

    @property
    def block_number(self):
        print(self.get_w3.eth.block_number)
        return self.get_w3.eth.block_number

    @property
    def transfer_signature(self):
        for abi in self.erc20_abi:
            if abi['type'] == 'event' and abi['name'] == 'Transfer':
                inputs = ",".join([param["type"] for param in abi["inputs"]])
                transfer_signature_text = f"Transfer({inputs})"
                return self.get_w3.to_hex(self.get_w3.keccak(text=transfer_signature_text))

    def update_block(self, block_number: int):
        self.old_block = block_number

    def get_pairs(self, blockchain: Blockchain, token_address: str, pair_token: str):
        pairs = []
        pair_token = self.get_w3.to_checksum_address(pair_token)
        token_address = self.get_w3.to_checksum_address(token_address)
        token_address = self.get_w3.to_checksum_address(token_address)
        fees = [100, 500, 3000, 10000]
        for dex in blockchain.dexes:
            factory = core.get_factory_contract(self.blockchain, dex=dex)
            try:
                pair_contract_addr = factory.functions.getPair(token_address, pair_token).call()
                if pair_contract_addr != '0x0000000000000000000000000000000000000000':
                    pairs.append({"dex_id": dex.id, "pair": pair_contract_addr, 'dex_name': dex.name})
            except ABIFunctionNotFound:
                for fee in fees:
                    pair_contract_addr = factory.functions.getPool(token_address, pair_token, fee).call()
                    print(f'result for {fee}: {pair_contract_addr}')
                    if pair_contract_addr != '0x0000000000000000000000000000000000000000':
                        pairs.append({"dex_id": dex.id, "pair": pair_contract_addr, 'dex_name': dex.name})
                        break
        return pairs

    def check_for_pairs(self, blockchain: Blockchain, token_address: str) -> Dict:
        pairs = {}
        try:
            token = self.get_w3.to_checksum_address(token_address)
        except Exception:
            return pairs
        contract = self.get_w3.eth.contract(address=token, abi=self.erc20_abi)
        address = contract.address

        token_symbol = contract.functions.symbol().call()
        token_name = contract.functions.name().call()
        token_supply = contract.functions.totalSupply().call()
        token_decimals = contract.functions.decimals().call()
        if address == '0x0000000000000000000000000000000000000000':
            return pairs

        for pair_token in [self.wrapped_native, self.USDT, self.USDC]:

            _pairs = self.get_pairs(blockchain, token_address, pair_token)
            #            print(f'Pair of {token} with {pair_token}: {pair}')

            for pair_info in _pairs:
                pair_token_contract = self.get_w3.eth.contract(address=pair_token, abi=self.erc20_abi)
                pair_token_symbol = pair_token_contract.functions.symbol().call()
                pairs[f"{token_symbol}/{pair_token_symbol}"] = {
                    "pair_address": pair_info['pair'],
                    "name": token_name,
                    "symbol": token_symbol,
                    "pair_token": pair_token,
                    "token": token,
                    "token_supply": token_supply,
                    "dex": pair_info['dex_id'],
                    "decimals": token_decimals
                }

        return pairs

    def _filter(self, tx_hash, filters):
        # print(f'Processing {tx_hash} | Filters: {filters}')
        try:
            receipt = self.get_w3.eth.get_transaction_receipt(tx_hash)
        except Exception as e:
            print(e)
            return
        if not receipt['logs']:
            # print('No logs!')
            return
        contracts_in_tx = [
            [log["address"] for t in log['topics'] if self.get_w3.to_hex(t) == self.transfer_signature][0]
            for log in receipt['logs']
            if log["address"] for t in log['topics'] if self.get_w3.to_hex(t) == self.transfer_signature
        ]
        # {"0x123 token": {"0x111 pair": [123group settings, 345group]}, {"0x222 pair: [678group,]}}
        for token, pair_groups in filters.items():
            # print(f"IN PROCESSING {token} | {pair_groups}")
            if token in contracts_in_tx:
                print(f'{token} in {tx_hash}')
                receipt_from = receipt['from']
                for pair, groups in pair_groups.items():
                    for gs in groups:
                        print(f'putting for post: {tx_hash} to {gs}')
                        self.post_queue.put((gs, contracts_in_tx, receipt, tx_hash, pair, receipt_from))
            #                        self._process(gs, contracts_in_tx, receipt, tx_hash, pair, receipt_from)

    def _process(self, gs: GroupSettings, contracts_in_tx, receipt, tx_hash, pair, receipt_from):
        spent_token = spent_amount = usd_amount = bought_amount = 0
        smart_contract = None
        _contract = self.get_w3.eth.contract(contracts_in_tx[0], abi=self.erc20_abi)
        dl = _contract.events["Transfer"]().process_receipt(receipt)
        print(f'Good tx: {self.blockchain.explorer}tx/{tx_hash}\n')

        for n, smart_contract in enumerate(contracts_in_tx):
            decoded_log = dl[n]
            contract = self.get_w3.eth.contract(smart_contract, abi=self.erc20_abi) if n != 0 else _contract
            _from = decoded_log['args']['from']
            _to = decoded_log['args']['to']

            if any(
                    [
                        pair not in [_to, _from],
                        _to in ['0x0000000000000000000000000000000000000000']

                    ]
            ):
                continue
            token_decimals = contract.functions.decimals().call()
            value = decoded_log['args']['value'] * 10 ** -token_decimals
            print(value, smart_contract, _from, _to)

            # if from router and to lp pair == spent token

            if _from == gs.erctoken.dex.router_address and _to == pair:
                spent_token = contract.functions.name().call()
                spent_amount = value
                #                print(f'Router sent {spent_amount} of {spent_token} to LP pair at {pair}')

                if smart_contract == self.wrapped_native:
                    usd_amount += spent_amount * core.get_native_price(self.blockchain)
                else:
                    usd_amount += spent_amount
            elif _to == pair and smart_contract == gs.erctoken.pair_token:
                #                print('second case')
                spent_token = contract.functions.name().call()
                spent_amount = value

                if smart_contract == self.wrapped_native:
                    usd_amount += spent_amount * core.get_native_price(self.blockchain)
                else:
                    usd_amount += spent_amount

            if _from == pair and smart_contract == gs.erctoken.address:
                spent_amount = self.truncate(spent_amount, 2)
                usd_amount = self.truncate(usd_amount, 2)
                if _to == receipt['from']:
                    bought_amount = self.truncate(bought_amount + value, 2)
        if spent_amount:
            print(smart_contract, gs.erctoken)
            if smart_contract and smart_contract != gs.erctoken.address:
                print(f'SELL: {tx_hash}')
                return
            if usd_amount <= gs.min_buy:
                print(f'Less than min buy: {tx_hash}')
                return
            weight_factor = int(usd_amount // gs.step) + 1
            weight = emojize(gs.emoji) * (weight_factor if weight_factor < 40 else 40)
            holdings = core.get_token_balance(self.blockchain, gs.erctoken, receipt_from) - bought_amount
            if holdings <= 0:
                printable_position = "NEW!"
            else:
                percent = round(((float(bought_amount) / float(holdings)) * 100), 2)
                if int(percent) > 1000:
                    printable_position = 'over 1000%'
                else:
                    printable_position = f'🆙 {str(percent)}%'

            price = core.get_price(self.blockchain, gs.erctoken)
            marketcap, circulating, burnt = core.get_marketcap(self.blockchain, gs.erctoken, price)

            txlink = f'<a href="{self.blockchain.explorer}tx/{tx_hash}">TX</a>'
            chartlink = f'<a href="https://dexscreener.com/{self.blockchain.shortname.lower()}/{gs.erctoken.pair_address}">Chart</a>'
            buyerlink = f'<a href="{self.blockchain.explorer}/{receipt_from}">Buyer</a>'
            pcslink = f'<a href="{gs.erctoken.dex.url}/swap?outputCurrency={gs.erctoken.address}">{gs.erctoken.dex.name}</a>'
            resp = f'<b>{gs.erctoken.name} Buy!</b>' \
                   f'\n{weight}' \
                   f'\n💵 ${usd_amount} <b>({spent_amount} {spent_token})</b>' \
                   f'\n🪙 {bought_amount:,} <b>{gs.erctoken.symbol}</b>' \
                   f'\n{printable_position}' \
                   f'\n\n🏷️ Price <b>${format_price(price)}</b>' \
                   f'\n📊 MCap <b>${int(marketcap):,}</b>' \
                   f'\n\n' \
                   f'#️⃣ {txlink}      💫{chartlink}\n🥰 {buyerlink} 💳 {pcslink}'
            print(resp)
            self.db.sync_insert(
                Buy,
                token_address=gs.erctoken.address,
                tx_hash=tx_hash,
                blockchain=gs.erctoken.blockchain.shortname,
                signer=receipt_from,
                usd_amount=self.truncate(usd_amount, 5),
                paid_amount=float(format(spent_amount, ".5f")),
                paid_with=spent_token,
                token_amount=self.truncate(bought_amount, 2),
                market_cap=marketcap,
                price=price,
                printable_position=demojize(printable_position),
            )
            return
        print(f'Not a buy - {tx_hash}')
        return

    def _process_BASE(self, gs: GroupSettings, contracts_in_tx, receipt, tx_hash, pair, receipt_from):
        # PROCESS BASE ONLY
        w3 = self.get_w3

        spent_amount = usd_amount = bought_amount = 0
        smart_contract = None
        _contract = w3.eth.contract(contracts_in_tx[0], abi=self.erc20_abi)
        dl = _contract.events["Transfer"]().process_receipt(receipt)
        print(f'Good tx: www.basescan.org/tx/{tx_hash}\n')

        biggest_bought_amount = 0
        last_eth = 0
        highest_eth = 0
        buyer = None
        token: ERCToken = gs.erctoken
        ROUTER = token.dex.router_address
        print(f'Router; {ROUTER}')
        print(f'Pair; {pair}')
        for n, smart_contract in enumerate(contracts_in_tx):
            decoded_log = dl[n]
            contract = w3.eth.contract(smart_contract, abi=self.erc20_abi) if n != 0 else _contract
            _from = decoded_log['args']['from']
            _to = decoded_log['args']['to']
            print(_to, _from, )
            if any(
                    [
                        ROUTER not in [_to, _from] and pair not in [_to, _from] and receipt_from not in [_to],
                        _to in ['0x0000000000000000000000000000000000000000']

                    ]
            ):
                continue
            token_decimals = contract.functions.decimals().call()
            value = decoded_log['args']['value'] * 10 ** -token_decimals
            # print(value, smart_contract, _from, _to)
            # if from router and to lp pair == spent token
            if smart_contract == token.blockchain.native_address:
                last_eth = value
                if last_eth > highest_eth:
                    highest_eth = last_eth
            """
            from = 0x9aBaB65D07643E1eF2329B15dFBf733C78E5fd57 
            pair = 0x9aBaB65D07643E1eF2329B15dFBf733C78E5fd57 
            router = 0x3fC91A3afd70395Cd496C647d5a6CC9D4B2b7FAD 
            _to = 0x3fC91A3afd70395Cd496C647d5a6CC9D4B2b7FAD
            """
            print(_from, pair, ROUTER, _to)
            if smart_contract in [token.address]:
                bought_amount = value
                print(f'sosos {value}')
            print(value, receipt_from, _to, smart_contract)
            if _to == receipt_from and smart_contract in [token.address]:
                print(f'vis movement {bought_amount}')
                if bought_amount > biggest_bought_amount:
                    print(f'buyer is now {_to}')
                    biggest_bought_amount = bought_amount
                    buyer = _to
            #if _from == ROUTER and _to == receipt_from:

            #                print(f'Router sent {spent_amount} of {spent_token} to LP pair at {pair}')

            """elif _to == pair and smart_contract == gs.pair_token:
    #                print('second case')
                spent_amount = value

                if smart_contract == WETH:
                    usd_amount += spent_amount * get_eth_price()
                else:
                    usd_amount += spent_amount"""

            if _from == pair and smart_contract in [token.address, ROUTER]:
                spent_amount = format(spent_amount, '.5f')
                usd_amount = format(usd_amount, '.5f')
                if _to == receipt['from']:
                    bought_amount = self.truncate(bought_amount + value, 2)
        spent_amount = highest_eth
        usd_amount = highest_eth * base_core.get_eth_price(w3)
        print(f'usd amount: {usd_amount}')
        if not buyer:
            for n, smart_contract in enumerate(contracts_in_tx):
                decoded_log = dl[n]
                contract = w3.eth.contract(smart_contract, abi=self.erc20_abi) if n != 0 else _contract
                _from = decoded_log['args']['from']
                _to = decoded_log['args']['to']
                print(_to, _from, )
                token_decimals = contract.functions.decimals().call()
                value = decoded_log['args']['value'] * 10 ** -token_decimals
                if smart_contract == token.pair_token:
                    buyer = _from
                    spent_amount = format(spent_amount, '.5f')
                    usd_amount = format(usd_amount, '.5f')
                if smart_contract == token.address and _to == buyer:
                    biggest_bought_amount = value
        if buyer:
            # print(f'usd_amount: {usd_amount}')
            if smart_contract and smart_contract not in [token.blockchain.native_address, token.address]:
                print(f'SELL: {tx_hash}')
                return
            usd_amount =  int(float(usd_amount))
            if usd_amount <= 100:
                print(f'Less than min buy: {tx_hash}')
                return
            weight_factor = int(usd_amount // gs.step) + 1
            weight = emojize(emojize(gs.emoji)) * (weight_factor if weight_factor < 40 else 40)
            holdings = core.get_token_balance(self.blockchain, gs.erctoken, buyer) - biggest_bought_amount
            if holdings <= 0:
                printable_position = "NEW! 🆕"
            else:
                percent = round(((float(bought_amount) / float(holdings)) * 100), 2)
                if int(percent) > 1000:
                    printable_position = '>1000% 😳'
                else:
                    printable_position = f'{str(percent)}% 🆙'

            price = base_core.alt_price(w3, float(spent_amount), float(bought_amount))
            marketcap, circulating, burnt = base_core.get_marketcap(w3, token.address, price, token.decimals)

            txlink = f'<a href="https://basescan.org/tx/{tx_hash}">TX</a>'
            chartlink = f'<a href="https://dexscreener.com/{self.blockchain.shortname.lower()}/{gs.erctoken.pair_address}">Chart</a>'
            buyerlink = f'<a href="{self.blockchain.explorer}/{receipt_from}">Buyer</a>'
            pcslink = f'<a href="{gs.erctoken.dex.url}/swap?outputCurrency={gs.erctoken.address}">{gs.erctoken.dex.name}</a>'

            resp = f'<b>{gs.erctoken.name} Buy!</b>' \
                   f'{weight}' \
                   f'\n\n💲 Spent: <b>{self.truncate(float(spent_amount), 5)} ETH</b> (${self.truncate(float(usd_amount), 2)})' \
                   f'\n\n💰 Got: {int(biggest_bought_amount):,} <b>{gs.erctoken.symbol}</b>' \
                   f'\n🔄 Buy Position: {printable_position}' \
                   f'\n✅ Dex: {token.dex.name.title()}' \
                   f'\n🏷️ Price <b>${format_price(price)}</b>' \
                   f'\n📊 MCap <b>${int(marketcap):,}</b>' \
                   f'\n\n' \
                   f'{txlink} | {chartlink} | {buyerlink} | {pcslink}'
            print(resp)
            self.db.sync_insert(
                Buy,
                token_address=gs.erctoken.address,
                tx_hash=tx_hash,
                blockchain=gs.erctoken.blockchain.shortname,
                signer=receipt_from,
                usd_amount=self.truncate(float(usd_amount), 5),
                paid_amount=float(format(float(spent_amount), ".5f")),
                paid_with='ETH',
                token_amount=self.truncate(float(bought_amount), 2),
                market_cap=marketcap,
                price=price,
                printable_position=demojize(printable_position),
            )
            return
        print(f'Not a buy - {tx_hash}')
        return

    @property
    def native_token_pair(self):
        pair = self.get_pairs(pair_token=self.wrapped_native, token=self.USDT)[0]
        native_usd_pair = self.get_w3.eth.contract(pair, abi=self.LP_abi)
        return native_usd_pair

    def get_eth_price(self):
        token0, token1, block = self.native_token_pair.functions.getReserves().call()
        price = token1 / token0 * 10 ** 12
        print(f'eth prce: {price}')
        return price

    def truncate(self, f, n):
        try:
            result = math.floor(f * 10 ** n) / 10 ** n
            if result <= 0:
                result = self.truncate(f, 2)
        except Exception:
            result = f
        return result

    def watch_blocks(self):
        print('Producer started')
        while True:
            print(1)
            try:
                print('yo')
                current_block = self.block_number
            except Exception as e:
                print('lala')
                print(e)
                continue
            print(current_block, self.old_block, current_block != self.old_block)
            if current_block != self.old_block:
                filters = self.get_filters()
                print(f'Logging block #{current_block}')
                self.update_block(current_block)
                block = None
                while not block:
                    try:
                        block = self.get_w3.eth.get_block(current_block, full_transactions=True)
                    except (web3.exceptions.BlockNotFound, ValueError, Exception) as e:
                        print(e)
                        time.sleep(1)

                for tx in block['transactions']:
                    tx_hash = self.get_w3.to_hex(tx['hash'])
                    self.queue.put((tx_hash, filters))
            time.sleep(.5)

    def log_blocks(self, consumer_id: int):
        print(f'Consumer #{consumer_id} started.')
        while True:
            tx_hash, filters = self.queue.get()
            self._filter(tx_hash, filters)

    def post_buys(self, poster_id: int):
        print(f'Poster #{poster_id} started.')
        while True:
            try:
                gs, contracts_in_tx, receipt, tx_hash, pair, receipt_from = self.post_queue.get()
                print(self.blockchain.id)
                if self.blockchain.id == 3:
                    print('processing base')
                    self._process_BASE(gs, contracts_in_tx, receipt, tx_hash, pair, receipt_from)
                else:
                    print('processing normal')
                    self._process(gs, contracts_in_tx, receipt, tx_hash, pair, receipt_from)
            except Exception:
                continue

    def schedule_post(self, text, group, tx_hash):
        db = self.db
        text = demojize(text)
        try:
            db.sync_insert(Buy, tx_hash=tx_hash, text=text, group=group.id)
        except Exception as e:
            print(e)
            pass

    def get_filters(self):
        db = self.db
        groups = db.sync_get(GroupSettings, get_type='scalars', key={'is_paused': False})
        print(groups)
        current_filters = {}
        # {"0x123 token": {"0x111 pair": [123group settings, 345group]}, {"0x222 pair: [678group,]}}

        for gs in groups:
            if not gs.erctoken or not gs.erctoken.pair_address:
                continue
            if gs.erctoken not in current_filters:
                current_filters[gs.erctoken.address] = {
                    gs.erctoken.pair_address: [gs]
                }
            else:
                copy = current_filters[gs.erctoken.address].copy()
                if gs.pair_address not in copy:
                    copy[gs.erctoken.pair_address] = [gs]
                else:
                    copy[gs.erctoken.pair_address].append(gs)
                current_filters[gs.erctoken.address] = copy
        return current_filters

    def run(self):
        print('Starting...')
        producer = Process(target=self.watch_blocks, daemon=True)

        for i in range(10):
            consumer = Process(target=self.log_blocks, daemon=True, args=(i,))
            consumer.start()
        for i in range(3):
            poster = Process(target=self.post_buys, daemon=True, args=(i,))
            poster.start()

        producer.start()

        while True:
            pass

    def test_run(self, tx_hash):
        filters = self.get_filters()
        self.queue.put((tx_hash, filters))
        tx_hash, filters = self.queue.get()
        self._filter(tx_hash, filters)
        gs, contracts_in_tx, receipt, tx_hash, pair, receipt_from = self.post_queue.get()
        if self.blockchain.id == 3:
            print('processing base')
            self._process_BASE(gs, contracts_in_tx, receipt, tx_hash, pair, receipt_from)
        else:
            print('processing normal')
            self._process(gs, contracts_in_tx, receipt, tx_hash, pair, receipt_from)


def zero_amt(n, q=0):
    if n >= 1:
        return q - 1
    n = n * 10
    return zero_amt(n, q + 1)


def truncate(f, n):
    result = math.floor(f * 10 ** n) / 10 ** n
    if result <= 0:
        result = truncate(f, 5)
    return result


def format_price(price):
    # Mapping of digits to their subscript counterparts
    zeroes = zero_amt(price)
    exponent_price = str(truncate(price, zeroes + 4) * (10 ** zeroes))
    SUB = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")
    new_price = exponent_price[exponent_price.index(".") + 1:exponent_price.index(".") + 5]
    price = f'0.0{str(zeroes).translate(SUB)}{new_price}'
    return price


def test_run():
    db = database.Client(
            host='localhost',
            username='root',
            password='<tDAXfuU7>',
            name=bot_config.project)

    chain = db.sync_get(Blockchain, key={'id': 3})
    monitor = MonitoringService(chain)
    monitor.test_run(
        tx_hash='0x00624d02de6facfb4ce2c0ba02f572f96709c3f9bd636aa959360d0baea0d0f2'
    )


if __name__ == '__main__':
    #test_run()
    pass