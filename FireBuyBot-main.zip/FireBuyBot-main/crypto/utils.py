import json

import requests

from loader import HELIUS_KEY


def get_token_data(token):
    url = f"https://api.helius.xyz/v0/token-metadata?api-key={HELIUS_KEY}"
    nft_addresses = [
        token
    ]

    headers = {
        'Content-Type': 'application/json',
    }

    data = {
        'mintAccounts': nft_addresses,
        'includeOffChain': True,
        'disableCache': False,
    }
    response = requests.post(url, headers=headers, data=json.dumps(data))
    data = response.json()
    _data = {}
    print(data)
    if not data or not data[0] or 'legacyMetadata' not in data[0]:
        return {}
    meta = data[0]['offChainMetadata']['metadata']

    try:
        if meta and 'name' in meta:
            _data['name'] = meta['name']
            _data['symbol'] = meta['symbol']
            # _data = data[0]['legacyMetadata']#['metadata']['data']
            _data['supply'] = data[0]['onChainAccountInfo']['accountInfo']['data']['parsed']['info']['supply']
            _data['decimals'] = data[0]['onChainAccountInfo']['accountInfo']['data']['parsed']['info']['decimals']
        else:
            meta = data[0]['onChainMetadata']['metadata']['data']
            xtra = data[0]['onChainAccountInfo']['accountInfo']['data']['parsed']['info']
            _data['name'] = meta['name']
            _data['symbol'] = meta['symbol']
            # _data = data[0]['legacyMetadata']#['metadata']['data']
            _data['supply'] = xtra['supply']
            _data['decimals'] = xtra['decimals']
    except Exception as e:
        print(e)
        return {}

    return _data


if __name__ == '__main__':
    #print(get_token_data('4GaRjXkFdWcatD6A7EZNBiRm21a3i2FX9geWASz8jbPk'))
    pass