import asyncio

from database.models import Blockchain
from loader import get_db
from monitoring_service import MonitoringService


async def main():
    db = get_db()
    blockchain: Blockchain = await db.get(Blockchain, key={'id': 5})
    monitor = MonitoringService(blockchain)
    monitor.run()


if __name__ == '__main__':
    asyncio.run(main())