import sqlalchemy.engine
from sqlalchemy import create_engine, select, update as upd, insert as ins, delete as dlt, insert
from sqlalchemy.orm import sessionmaker, joinedload
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession


class Client:
    def __init__(
            self,
            username: str,
            password: str,
            host: str,
            name: str
    ) -> None:
        self.username = username
        self.password = password
        self.host = host
        self.name = name

        self.engine = create_engine(
            self.engine_string(),
            pool_size=50,
            max_overflow=100
        )

        self.async_engine = create_async_engine(
            self.engine_string(async_engine=True),
            pool_size=50,
            max_overflow=100
        )

        self.Session = sessionmaker(
            bind=self.engine,
            expire_on_commit=False,
        )
        self.AsyncSession = sessionmaker(
            bind=self.async_engine,
            expire_on_commit=False,
            class_=AsyncSession
        )

    def engine_string(self, async_engine: bool = False):
        return "mysql+{}://{}:{}@{}/{}?charset=utf8mb4".format(
            "aiomysql" if async_engine else "mysqldb",
            self.username,
            self.password,
            self.host,
            self.name
        )

    async def get(
            self,
            table,
            key=None,
            where=None,
            offset=None,
            order_by=None,
            limit=None,
            get_type='scalar',
            relationships=None
    ) -> sqlalchemy.engine.Row:
        async with self.AsyncSession.begin() as session:
            stmt = select(table)
            if where is not None:
                stmt = stmt.where(where)
            if key is not None:
                stmt = stmt.filter_by(**key)
            if offset is not None:
                stmt = stmt.offset(offset)
            if order_by is not None:
                stmt = stmt.order_by(order_by)
            if limit is not None:
                stmt = stmt.limit(limit)
            if relationships:
                for relationship in relationships:
                    path = relationship.split('.')
                    if len(path) > 1:
                        rel, nested_rel = path
                        stmt = stmt.options(joinedload(rel).joinedload(nested_rel))
                    else:
                        stmt = stmt.options(joinedload(relationship))
            result = await getattr(session, get_type)(
                stmt
            )
            return result.all() if get_type == 'scalars' else result

    async def update(self, table, key=None, **kwargs):
        async with self.AsyncSession.begin() as session:
            statement = upd(
                table
            ).values(
                **kwargs
            )
            if key:
                statement = statement.filter_by(
                    **key
                )
            await session.execute(
                statement
            )

    async def delete(self, table, key):
        async with self.AsyncSession.begin() as session:
            await session.execute(
                dlt(
                    table
                ).filter_by(
                    **key
                )
            )

    async def insert(self, table, **kwargs):
        async with self.AsyncSession.begin() as session:
            await session.execute(
                ins(
                    table
                ).values(
                    **kwargs
                )
            )

    def sync_insert(self, table, **kwargs) -> sqlalchemy.engine.Row:
        with self.Session.begin() as session:
            key = session.execute(
                insert(
                    table
                ).values(
                    **kwargs
                )
            ).inserted_primary_key[0]
            return key

    def sync_get(self,
                 table,
                 key=None,
                 where=None,
                 offset=None,
                 order_by=None,
                 limit=None,
                 get_type='scalar',
                 relationships=None
                 ) -> sqlalchemy.engine.Row:
        with self.Session.begin() as session:
            stmt = select(table)
            if where is not None:
                stmt = stmt.where(where)
            if key is not None:
                stmt = stmt.filter_by(**key)
            if offset is not None:
                stmt = stmt.offset(offset)
            if order_by is not None:
                stmt = stmt.order_by(order_by)
            if limit is not None:
                stmt = stmt.limit(limit)
            if relationships:
                for relationship in relationships:
                    path = relationship.split('.')
                    if len(path) > 1:
                        rel, nested_rel = path
                        stmt = stmt.options(joinedload(rel).joinedload(nested_rel))
                    else:
                        stmt = stmt.options(joinedload(relationship))
            result = getattr(session, get_type)(
                stmt
            )
            print(result)
            return result.all() if get_type == 'scalars' else result

    async def toggle(self, table, column, new_value, table_id, table_id_value):
        async with self.AsyncSession.begin() as session:
            await session.execute(
                upd(
                    table
                ).values(
                    **{column: new_value}
                ).filter_by(
                    **{table_id: table_id_value}
                )
            )
