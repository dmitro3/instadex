from contextlib import suppress

import sqlalchemy.exc

from loader import get_db
from database import models, Client
from sqlalchemy import insert
from sqlalchemy_utils import create_database, drop_database


def insert_chains(db: Client):
    CHAINS = [
        {
            "name": "BSC",
            "shortname": "bsc",
            "native_name": "Binance Coin",
            "native_symbol": "BNB",
            "native_address": "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
            "usdt": "0x55d398326f99059fF775485246999027B3197955",
            "usdc": "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d",
            "explorer": "https://www.bscscan.com/",
            "rpc": "https://bsc-dataseed1.binance.org/",
            "trending_channel_id": -1002092320786,
            "trending_channel_username": 'Bsc_Trendings_Live',
        },
        {
            "name": "Ethereum",
            "shortname": "ethereum",
            "native_name": "Ether",
            "native_symbol": "ETH",
            "native_address": "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
            "usdt": "0xdAC17F958D2ee523a2206206994597C13D831ec7",
            "usdc": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
            "explorer": "https://www.etherscan.io/",
            "rpc": "https://lb.drpc.org/ogrpc?network=ethereum&dkey=AlRznNlh8Er1nGz6f-bRywmXTiPMTCcR7pVqdk2eQLM2",
            "trending_channel_id": -1002102291609,
            "trending_channel_username": 'Eth_Trending_Live',
        },
        {
            "name": "Base",
            "shortname": "base",
            "native_name": "Ether",
            "native_symbol": "ETH",
            "native_address": "0x4200000000000000000000000000000000000006",
            "usdt": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
            "usdc": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 ",
            "explorer": "https://www.basescan.org/",
            "rpc": "https://base-mainnet.blastapi.io/054d2eda-da35-4e99-ac66-3d643715c413",
            "trending_channel_id": -1002072812012,
            "trending_channel_username": 'BaseL2Trending',
        },
        {
            "name": "Blast L2",
            "shortname": "blast",
            "native_name": "Ether",
            "native_symbol": "ETH",
            "native_address": "0x4300000000000000000000000000000000000004",
            "usdt": "0x4300000000000000000000000000000000000003",
            "usdc": "0x4300000000000000000000000000000000000003",
            "explorer": "https://blastscan.io/",
            "rpc": "https://rpc.blast.io/",
            "trending_channel_id": -1002039399623,
            "trending_channel_username": 'BlastL2Trending',
        },
        {
            "name": "Polygon",
            "shortname": "polygon",
            "native_name": "Matic",
            "native_symbol": "MATIC",
            "native_address": "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270",
            "usdt": "0xc2132D05D31c914a87C6611C10748AEb04B58e8F",
            "usdc": "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",
            "explorer": "https://polygonscan.com/",
            "rpc": "https://polygon-rpc.com",
            "trending_channel_id": -1002039399623,
            "trending_channel_username": 'PolygonTrendingLive',
        }
    ]
    """
    {
            "name": "Goerli [TESTNET]",
            "native_name": "Ether",
            "native_symbol": "ETH",
            "native_address": "0xb4fbf271143f4fbf7b91a5ded31805e42b2208d6",
            "usdt": "0x509Ee0d083DdF8AC028f2a56731412edD63223B9",
            "explorer": "https://www.goerli.etherscan.io/"
        },
    """

    for c in CHAINS:
        insert_chain(db, c)


def insert_chain(db, c):
    db.sync_insert(models.Blockchain, **c)


def insert_dexes(db: Client):
    DEXES = [
        {
            "name": "PancakeSwapV2",
            "router_address": "0x10ED43C718714eb63d5aA57B78B54704E256024E",
            "factory_address": "0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73",
            "blockchain_id": 1,
            "url": "https://pancakeswap.finance"
        },
        {
            "name": "PancakeSwapV3",
            "router_address": "0x1b81D678ffb9C0263b24A97847620C99d213eB14",
            "factory_address": "0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865",
            "blockchain_id": 1,
            "url": "https://pancakeswap.finance"
        },
        {
            "name": "UniSwapV2",
            "router_address": "0x10ED43C718714eb63d5aA57B78B54704E256024E",
            "factory_address": "0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f",
            "blockchain_id": 2,
            "url": "https://app.uniswap.org/#"
        },
        {
            "name": "UniSwapV3",
            "router_address": "0xE592427A0AEce92De3Edee1F18E0157C05861564",
            "factory_address": "0x1F98431c8aD98523631AE4a59f267346ea31F984",
            "blockchain_id": 2,
            "url": "https://app.uniswap.org/#"
        },
        {
            "name": "BaseSwapV2",
            "router_address": "0x3fC91A3afd70395Cd496C647d5a6CC9D4B2b7FAD",
            "factory_address": "0xFDa619b6d20975be80A10332cD39b9a4b0FAa8BB",
            "blockchain_id": 3,
            "url": "https://baseswap.fi/#"
        },
        {
            "name": "DYOR Swap V2",
            "router_address": "0xE470699f6D0384E3eA68F1144E41d22C6c8fdEEf",
            "factory_address": "0xa1da7a7eb5a858da410de8fbc5092c2079b58413",
            "blockchain_id": 4,
            "url": "https://dyorswap.finance/swap/?chainId=81457"
        },
        {
            "name": "Thruster Swap V2",
            "router_address": "0x44889b52b71E60De6ed7dE82E2939fcc52fB2B4E",
            "factory_address": "0xb4A7D971D0ADea1c73198C97d7ab3f9CE4aaFA13",
            "blockchain_id": 4,
            "url": "https://app.thruster.finance/swap?"
        },
        {
            "name": "Thruster Swap V3",
            "router_address": "0x337827814155ECBf24D20231fCA4444F530C0555",
            "factory_address": "0x71b08f13B3c3aF35aAdEb3949AFEb1ded1016127",
            "blockchain_id": 4,
            "url": "https://app.thruster.finance/swap?"
        },
        {
            "name": "QuickSwap V2",
            "router_address": "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff",
            "factory_address": "0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32",
            "blockchain_id": 5,
            "url": "https://quickswap.exchange/#/swap?"
        },
        {
            "name": "QuickSwap V3",
            "router_address": "0x802b65b5d9016621E66003aeD0b16615093f328b",
            "factory_address": "0x411b0fAcC3489691f28ad58c47006AF5E3Ab3A28",
            "blockchain_id": 5,
            "url": "https://quickswap.exchange/#/swap?"
        },
        {
            "name": "UniSwap V3",
            "router_address": "0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45",
            "factory_address": "0x1F98431c8aD98523631AE4a59f267346ea31F984",
            "blockchain_id": 5,
            "url": "https://quickswap.exchange/#/swap?"
        }

    ]
    for d in DEXES:
        insert_dex(db, d)


def insert_dex(db, d):
    db.sync_insert(models.DEX, **d)


def init_settings(db: Client):
    with db.Session.begin() as session:
        session.execute(
            insert(
                models.GlobalSettings
            )
        )


def init():
    """
    Create Database and do the
    """
    confirm = input('You are about to nuke the database and lose all the data. Proceed? (y/n): ')
    if confirm.lower().strip() != 'y':
        print('Database nuke aborted.')
        return
    db = get_db()
    engine = db.engine
    with suppress(sqlalchemy.exc.OperationalError):
        drop_database(db.engine_string())
    create_database(db.engine_string())
    models.Base.metadata.create_all(bind=engine)

    init_settings(db)
    insert_chains(db)
    insert_dexes(db)


    print('Database nuked and restarted.')


def soft_init():
    """
    Update Database with new tables
    """

    db = get_db()
    engine = db.engine
    models.Base.metadata.create_all(bind=engine)
    print('Database update with new tables.')


if __name__ == '__main__':
    d = {
            "name": "UniSwap V2",
            "router_address": "0xECB03B9a0E7F7B5E261d3Ef752865af6621a54Fe",
            "factory_address": "0x8909Dc15e40173Ff4699343b6eB8132c65e18eC6",
            "blockchain_id":3,
            "url": "https://baseswap.fi/#"
        }
    insert_dex(get_db(), d)
    #soft_init()
