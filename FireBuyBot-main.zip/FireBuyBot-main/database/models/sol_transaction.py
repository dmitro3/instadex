from sqlalchemy import Column, BigInteger, String, DateTime, func, Boolean

from .BASE import Base


class SolTransaction(Base):
    __tablename__ = 'sol_transaction'
    id = Column(BigInteger, primary_key=True)
    tx_hash = Column(String(128), nullable=False, unique=True)
    in_processing = Column(Boolean, default=False)

    created_at = Column(DateTime, default=func.now())

    def __repr__(self):
        return f"<SolTransaction(id='{self.id}')>\n\n{self.tx_hash}"
