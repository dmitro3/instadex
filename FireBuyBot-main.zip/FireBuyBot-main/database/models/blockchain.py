from sqlalchemy import Column, String, Integer, Text, BigInteger
from sqlalchemy.orm import relationship

from .BASE import Base


class Blockchain(Base):
    """Blockchain model class"""

    __tablename__ = 'blockchain'
    id = Column(Integer, primary_key=True)
    name = Column(String(32), nullable=False, unique=True)
    shortname = Column(String(32), nullable=False, unique=True)
    explorer = Column(String(128), nullable=False)
    rpc = Column(Text, nullable=False)
    usdt = Column(String(44), nullable=False)
    usdc = Column(String(44), nullable=False)

    native_name = Column(String(64), nullable=False)
    native_symbol = Column(String(8), nullable=False)
    native_address = Column(String(44), nullable=False)

    dexes = relationship(
        "DEX", foreign_keys="DEX.blockchain_id", back_populates="blockchain", lazy='subquery'
    )
    tokens = relationship(
        "ERCToken", foreign_keys="ERCToken.blockchain_id", back_populates="blockchain", lazy='subquery'
    )

    trending_channel_username = Column(String(64), default=None)
    trending_channel_id = Column(BigInteger, default=None)
    trending_message_id = Column(BigInteger, default=None)

    def __str__(self):
        return "<Blockchain(id={}, name={}, native={} ({}) {})>"\
            .format(self.id, self.name, self.native_name, self.native_symbol, self.native_address)
