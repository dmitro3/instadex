from sqlalchemy import Column, BigInteger, Enum, ForeignKey, func, DateTime, Float, String, Text, Integer
from sqlalchemy.orm import relationship

from .sol_token import SolToken
from .ton_token import TonToken
from .erctoken import ERCToken
from .BASE import Base
from .user import User


class Order(Base):
    __tablename__ = 'order'
    id = Column(BigInteger, primary_key=True)
    payment_id = Column(String(16), nullable=True)
    status = Column(
        Enum(
            'waiting',
            'confirming',
            'confirmed',
            'sending',
            'partially_paid',
            'finished',
            'failed',
            'refunded',
            'expired'
        ),
        nullable=False)
    address = Column(String(128), nullable=True)
    pay_currency = Column(String(16), nullable=False)
    amount_usd = Column(Float(18, decimal_return_scale=8), nullable=False)
    had_to_pay = Column(Float(18, decimal_return_scale=8), nullable=True)
    actually_paid = Column(Float(18, decimal_return_scale=8), nullable=True)
    description = Column(Text, default=None)
    place = Column(Integer, nullable=False)
    hours = Column(Integer, nullable=False)

    blockchain = Column(String(8), default='sol')
    tg_group = Column(String(255), default=None)

    user_id = Column(ForeignKey(User.id, ondelete='cascade', onupdate='cascade'), nullable=True)
    user = relationship('User', back_populates='orders', lazy='subquery', foreign_keys=[user_id])

    presale_pool_address = Column(String(64), default=None)
    erc_token_id = Column(ForeignKey(ERCToken.id, onupdate='cascade', ondelete='cascade'))
    erctoken = relationship('ERCToken', backref='order', lazy='subquery', foreign_keys=[erc_token_id])

    ton_token_address = Column(ForeignKey(TonToken.address, onupdate='cascade', ondelete='cascade'))
    ton_token = relationship('TonToken', backref='order', lazy='subquery', foreign_keys=[ton_token_address])

    sol_token_address = Column(ForeignKey(SolToken.address, onupdate='cascade', ondelete='cascade'))
    sol_token = relationship('SolToken', backref='order', lazy='subquery', foreign_keys=[sol_token_address])

    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    def __repr__(self):
        return "<Order(id={}, status='{}', description='{}', user={})>".format(self.id, self.status, self.description, self.user)
