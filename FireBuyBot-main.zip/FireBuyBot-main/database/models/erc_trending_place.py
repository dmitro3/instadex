from sqlalchemy import Column, BigInteger, DateTime, func, Boolean, ForeignKey, Integer
from sqlalchemy.orm import relationship

from .blockchain import Blockchain
from .erctoken import ERCToken
from .BASE import Base


class ERCTrendingPlace(Base):
    __tablename__ = 'erc_trending_place'
    id = Column(BigInteger, primary_key=True)
    place = Column(Integer, default=3)
    is_active = Column(Boolean, default=False)

    blockchain_id = Column(ForeignKey(Blockchain.id, onupdate='cascade', ondelete='cascade'))
    blockchain = relationship('Blockchain', backref='tredning_places', lazy='subquery', foreign_keys=[blockchain_id])

    erc_token_id = Column(ForeignKey(ERCToken.id, onupdate='cascade', ondelete='cascade'))
    erc_token = relationship('ERCToken', backref='_trending_place', lazy='subquery', foreign_keys=[erc_token_id])

    created_at = Column(DateTime, default=func.now())
    until = Column(DateTime)

    def __repr__(self):
        return f"<ERCTrendingPlace(id='{self.id}')> {self.erc_token} {self.place}"
