from sqlalchemy import Column, BigInteger, String, DateTime, func, Boolean, ForeignKey, Integer
from sqlalchemy.orm import relationship

from .sol_token import SolToken
from .BASE import Base


class SolTrendingPlace(Base):
    __tablename__ = 'sol_trending_place'
    id = Column(BigInteger, primary_key=True)
    place = Column(Integer, default=3)
    is_active = Column(Boolean, default=False)

    token_address = Column(ForeignKey(SolToken.address, onupdate='cascade', ondelete='cascade'))
    token = relationship('SolToken', backref='_trending_place', lazy='subquery', foreign_keys=[token_address])

    created_at = Column(DateTime, default=func.now())
    until = Column(DateTime)

    def __repr__(self):
        return f"<SolTrendingPlace(id='{self.id}')> {self.token} {self.place}"
