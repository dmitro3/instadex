from sqlalchemy import Column, String, Integer, Boolean

from .BASE import Base


class SolToken(Base):
    __tablename__ = 'sol_token'
    address = Column(String(44), primary_key=True)
    name = Column(String(128), nullable=False)
    symbol = Column(String(16), nullable=False)
    decimals = Column(Integer, default=18)
    supply = Column(String(64), default='0')
    trending_place = Column(Integer, default=None)

    def __repr__(self):
        return "<SolToken(name='{}', address={})>"\
            .format(self.name, self.address)
