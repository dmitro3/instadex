from sqlalchemy import Column, BigInteger, String, DateTime, func, Boolean

from .BASE import Base


class TonTransaction(Base):
    __tablename__ = 'ton_transaction'
    id = Column(BigInteger, primary_key=True)
    tx_hash = Column(String(128), nullable=False, unique=True)
    in_processing = Column(Boolean, default=False)

    created_at = Column(DateTime, default=func.now())

    def __repr__(self):
        return f"<TonTransaction(id='{self.id}')>\n\n{self.tx_hash}"
