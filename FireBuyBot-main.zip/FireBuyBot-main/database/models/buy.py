from sqlalchemy import Column, BigInteger, String, Boolean, DateTime, func, Float

from .BASE import Base


class Buy(Base):
    __tablename__ = 'buy'
    id = Column(BigInteger, primary_key=True)
    blockchain = Column(String(32), default='ethereum')
    tx_hash = Column(String(128), nullable=False, unique=True)
    token_address = Column(String(128), nullable=False)
    signer = Column(String(128), nullable=False)
    usd_amount = Column(Float, nullable=False)
    market_cap = Column(Float, nullable=False)
    paid_amount = Column(Float, nullable=False)
    paid_with = Column(String(8), nullable=False)
    token_amount = Column(String(64), nullable=False)
    printable_position = Column(String(64), nullable=False)
    price = Column(Float, nullable=False)
    is_whale = Column(Boolean, default=False)

    created_at = Column(DateTime, default=func.now())
    is_posted = Column(Boolean, default=False)
    posted_at = Column(DateTime, onupdate=func.now(), default=None)

    def __repr__(self):
        return f"<Buy(id='{self.id}')>\n\n{self.token_address}"
