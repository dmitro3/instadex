from sqlalchemy import Column, String, BigInteger, Integer, LargeBinary, Boolean, ForeignKey
from sqlalchemy.dialects.mysql import LONGBLOB
from sqlalchemy.orm import relationship

from . import SolToken, TonToken
from .erctoken import ERCToken
from .BASE import Base


class GroupSettings(Base):
    __tablename__ = 'group_settings'
    id = Column(BigInteger, primary_key=True)
    title = Column(String(255))
    username = Column(String(64))
    name = Column(String(64), default=None)
    
    min_buy = Column(Integer, default=100)
    step = Column(Integer, default=100)
    custom_supply = Column(String(36), default=None)
    emoji = Column(String(64), default=':green_circle:')
    is_paused = Column(Boolean, default=False)
    media_enabled = Column(Boolean, default=False)
    media = Column(LargeBinary().with_variant(LONGBLOB, 'mysql'))
    media_type = Column(String(16))
    media_threshold = Column(Integer, default=100)
    members_count = Column(Integer, default=1)

    erctoken_id = Column(ForeignKey(ERCToken.id, onupdate='cascade', ondelete='cascade'))
    erctoken = relationship('ERCToken', backref='group_eth_token', lazy='subquery', foreign_keys=[erctoken_id])

    sol_token_address = Column(ForeignKey(SolToken.address, onupdate='cascade', ondelete='cascade'))
    sol_token = relationship('SolToken', backref='group_sol_token', lazy='subquery', foreign_keys=[sol_token_address])

    ton_token_address = Column(ForeignKey(TonToken.address, onupdate='cascade', ondelete='cascade'))
    ton_token = relationship('TonToken', backref='group_ton_token', lazy='subquery', foreign_keys=[ton_token_address])

    def __repr__(self):
        return "<GroupSettings(name='{}', group_id={})>"\
            .format(self.name, self.id)
