from sqlalchemy import Column, String, DateTime, func, BigInteger
from sqlalchemy.orm import relationship

from .BASE import Base


class User(Base):
    __tablename__ = 'user'
    id = Column(BigInteger, primary_key=True)
    full_name = Column(String(64), nullable=False)
    username = Column(String(64))

    last_active = Column(DateTime, default=func.now(), onupdate=func.now())

    orders = relationship("Order", foreign_keys="Order.user_id", back_populates="user", lazy='subquery')

    def __repr__(self):
        return "<User(id={}, full_name='{}', username='@{}', last_active={})>"\
            .format(self.id, self.full_name, self.username, self.last_active.date())
