from sqlalchemy import Column, BigInteger, DateTime, func, Boolean, ForeignKey, Integer
from sqlalchemy.orm import relationship

from .ton_token import TonToken
from .BASE import Base


class TonTrendingPlace(Base):
    __tablename__ = 'ton_trending_place'
    id = Column(BigInteger, primary_key=True)
    place = Column(Integer, default=3)
    is_active = Column(Boolean, default=False)

    token_address = Column(ForeignKey(TonToken.address, onupdate='cascade', ondelete='cascade'))
    token = relationship('TonToken', backref='_trending_place', lazy='subquery', foreign_keys=[token_address])

    created_at = Column(DateTime, default=func.now())
    until = Column(DateTime)

    def __repr__(self):
        return f"<TonTrendingPlace(id='{self.id}')> {self.token} {self.place}"
