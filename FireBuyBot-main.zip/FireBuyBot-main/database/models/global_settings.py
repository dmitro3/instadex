from sqlalchemy import Column, Text, BigInteger, Boolean, Float
from .BASE import Base


class GlobalSettings(Base):
    __tablename__ = 'global_settings'
    id = Column(BigInteger, primary_key=True)
    is_on = Column(Boolean, default=True)
    next_advert_text = Column(Text, default=None)
    next_advert_url = Column(Text, default=None)

    sol_price = Column(Float(18, decimal_return_scale=9), default=0.0)
    ton_price = Column(Float(18, decimal_return_scale=9), default=0.0)

    def __repr__(self):
        return "<GlobalSettings(is_on='{}', next_advert='{}')>" \
            .format(self.is_on, self.next_advert)
