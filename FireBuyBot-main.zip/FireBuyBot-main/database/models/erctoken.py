from sqlalchemy import Column, String, ForeignKey, Integer, BigInteger
from sqlalchemy.orm import relationship

from .blockchain import Blockchain
from .DEX import DEX
from .BASE import Base


class ERCToken(Base):
    __tablename__ = 'erctoken'
    id = Column(BigInteger, primary_key=True)
    address = Column(String(44), nullable=False)
    name = Column(String(128), nullable=False)
    symbol = Column(String(16), nullable=False)
    decimals = Column(Integer, default=18)
    pair_token = Column(String(42), default=None)
    pair_address = Column(String(42), default=None)

    trending_place = Column(Integer, default=None)

    blockchain_id = Column(ForeignKey(Blockchain.id, onupdate='cascade', ondelete='cascade'))
    blockchain = relationship('Blockchain', back_populates='tokens', lazy='subquery', foreign_keys=[blockchain_id])

    dex_id = Column(ForeignKey(DEX.id, onupdate='cascade', ondelete='cascade'))
    dex = relationship('DEX', backref='dex_token', lazy='subquery', foreign_keys=[dex_id])

    def __repr__(self):
        return "<Token(address='{}', pair_token={})>"\
            .format(self.name, self.pair_token)
