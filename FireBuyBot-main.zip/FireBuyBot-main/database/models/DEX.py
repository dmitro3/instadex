from sqlalchemy import Column, String, Integer, ForeignKey, Text
from sqlalchemy.orm import relationship

from .BASE import Base
from .blockchain import Blockchain


class DEX(Base):
    """DEX model class"""

    __tablename__ = 'dex'
    id = Column(Integer, primary_key=True)
    name = Column(String(32), nullable=False)
    url = Column(Text, nullable=False)

    router_address = Column(String(44), nullable=False)
    factory_address = Column(String(44), nullable=False)

    blockchain_id = Column(ForeignKey(Blockchain.id, onupdate='cascade', ondelete='cascade'))
    blockchain = relationship('Blockchain', back_populates='dexes', lazy='subquery', foreign_keys=[blockchain_id])

    def __str__(self):
        return "<DEX(id={}, name={}, router={}, factory={}, blockchain={})>"\
            .format(self.id, self.name, self.router_address, self.factory_address, self.blockchain)
