from sqlalchemy import Column, String, Integer, Boolean

from .BASE import Base


class TonToken(Base):
    __tablename__ = 'ton_token'
    address = Column(String(64, collation='utf8mb3_general_ci'), primary_key=True)
    name = Column(String(128), nullable=False)
    symbol = Column(String(16), nullable=False)
    decimals = Column(Integer, default=18)
    supply = Column(String(64), default='0')
    trending_place = Column(Integer, default=None)

    def __repr__(self):
        return "<TonToken(name='{}', address={})>"\
            .format(self.name, self.address)
