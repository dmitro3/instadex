import logging
import os

from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from plate import Plate

import database
from config import bot_config
from database.models import Blockchain
from monitoring_service import MonitoringService

logging.basicConfig(level=logging.INFO)
logging.getLogger('apscheduler.executors.default').propagate = False

bot = Bot(token=bot_config.token, parse_mode='HTML')
storage = MemoryStorage()
dp = Dispatcher()

NOWPAYMENTS_KEY = 'VZ6QVN9-BVQ413N-KHT11FA-H8VSV36'
HELIUS_KEY = '46aeeaea-4b37-416f-9402-0f7e6395f671'

try:
    plate = Plate(root='locales')
except:
    os.chdir('../')


locales = {'en': 'en_US'}


def get_db():
    return database.Client(
        host='localhost',
        username='root',
        password='<tDAXfuU7>',
        name=bot_config.project)


def get_monitor(blockchain: Blockchain) -> MonitoringService:
    monitor = MonitoringService(blockchain=blockchain)
    return monitor


