import asyncio
import logging

import handlers
import database
import chat_member_events

import loader
from filters import UserFilter
from handlers import routers
from middlewares import ThrottlingMiddleware, DBMiddleware

logger = logging.getLogger(__name__)


async def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    )
    logger.error("Starting bot")
    dp = loader.dp
    bot = loader.bot
    dp.message.middleware(ThrottlingMiddleware())
    dp.callback_query.middleware(ThrottlingMiddleware())

    dp.message.middleware(DBMiddleware())
    dp.callback_query.middleware(DBMiddleware())

    dp.message.filter(UserFilter())
    dp.callback_query.filter(UserFilter())

    dp.include_router(routers.superuser)
    dp.include_router(routers.group_user)
    dp.include_router(routers.group_admin)
    dp.include_router(routers.private)

    try:
        print(dp.resolve_used_update_types())
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.error("Bot stopped!")

