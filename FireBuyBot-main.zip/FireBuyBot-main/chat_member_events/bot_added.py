import asyncio

from aiogram.types import ChatMemberUpdated
from emoji.core import demojize
from config import bot_config
from database import models
from keyboards import get_deeplink
from loader import dp, plate, get_db, bot
from aiogram.filters.chat_member_updated import ChatMemberUpdatedFilter, MEMBER, RESTRICTED, KICKED, LEFT, \
    ADMINISTRATOR, CREATOR


@dp.my_chat_member(ChatMemberUpdatedFilter(
        member_status_changed=
        (KICKED | LEFT | -RESTRICTED)
        >>
        (+RESTRICTED | MEMBER | ADMINISTRATOR | CREATOR)
    ))
async def bot_added(event: ChatMemberUpdated):
    await asyncio.sleep(1)

    chat_id = event.chat.id
    chat_title = demojize(event.chat.title)
    chat_username = event.chat.username
    if event.from_user.id not in bot_config.admins:
        await dp.bot.leave_chat(chat_id)
    else:
        db = get_db()
        group = await db.get(models.GroupSettings, key={'id': chat_id})
        if not group:
            await db.insert(models.GroupSettings, id=chat_id, title=chat_title, username=chat_username)
        else:
            await db.update(models.GroupSettings, key={'id': chat_id}, title=chat_title, username=chat_username)

        if event.chat.type in ['group', 'supergroup']:
            kb = get_deeplink(link=f'https://t.me/{(await bot.get_me()).username}?start={event.chat.id}')
            await bot.send_message(chat_id, plate('group_response'), reply_markup=kb)
