import asyncio
import datetime
from typing import List

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from emoji import emojize

from database import Client
from database.models import SolToken, GroupSettings, Buy, GlobalSettings, SolTransaction, Order
from keyboards import get_deeplink
from loader import bot, get_db
from config import bot_config


async def update_trending(db: Client):
    # get paid trenders
    # sort by created at
    # get all buys for the last hour
    hour_ago = datetime.datetime.now() - datetime.timedelta(hours=1)
#    await db.delete(Buy, where=Buy.created_at < hour_ago)
    buys: List[Buy] = await db.get(Buy, key={'blockchain': 'sol'}, get_type='scalars', where=Buy.created_at > hour_ago)
    tokens_in_buys = set([b.token_address for b in buys])
#    print(tokens_in_buys)
    rating = []
    for t in tokens_in_buys:
        token_buys = await db.get(Buy, key={'token_address': t, 'blockchain': 'sol'}, get_type='scalars', where=Buy.created_at > hour_ago)
        change_percent = ((float(token_buys[-1].price) - float(token_buys[0].price)) / float(token_buys[0].price)) * 100
        token: Token = await db.get(Token, key={'address': t})
        if not token:
            continue
        if change_percent < 0:
            pass
        unique_buyers = len([i for i in token_buys if i.printable_position == 'NEW!'])
        rating.append({
            "token": token.address,
            "change": change_percent,
            "buys_amount": len(token_buys),
            "volume": sum([tb.usd_amount for tb in token_buys]),
            "new_buyers": unique_buyers,
            "total_buyers": len(token_buys)
        })

    sorted_rating = sorted(rating, key=lambda x: x['volume'], reverse=True)[:14]
    old_trenders: List[Token] = [
        i.address for i in await db.get(Token, where=Token.trending_place is not None, get_type='scalars') if i.trending_place
    ]
    await db.update(Token, trending_place=None)
    trending_places: List[TrendingPlace] = await db.get(TrendingPlace, key={'is_active': True}, get_type='scalars', order_by=TrendingPlace.place)
    for tp in trending_places:
        if tp.until and tp.until < datetime.datetime.now():
            next_in_line: TrendingPlace = await db.get(
                TrendingPlace,
                key={'place': tp.place, 'is_active': False},
                order_by=TrendingPlace.created_at
            )
            await db.delete(TrendingPlace, key={'id': tp.id})
            if not next_in_line:
                continue
            _order = await db.get(Order, key={'token_address': next_in_line.erc_token_id})
            await db.update(TrendingPlace, key={'id': next_in_line.id}, is_active=True, until=datetime.datetime.now() + datetime.timedelta(hours=_order.hours))
            tp = next_in_line
            if not tp:
                continue
        token_buys = await db.get(Buy, key={'token_address': tp.erc_token_id, 'blockchain': 'sol'}, get_type='scalars', where=Buy.created_at > hour_ago)
        dontinsert = False
        try:
            change_percent = ((float(token_buys[-1].price) - float(token_buys[0].price)) / float(
                token_buys[0].price)) * 100
            unique_buyers = len([i for i in token_buys if i.printable_position == 'NEW!'])
            print(f'Inserting {tp.erc_token} to #{tp.place}')
            s = sorted_rating.copy()
            for n, data in enumerate(s):
                # this part checks if token that is paid for trending is already in the list and is in the place above that he paid for
                if data['token'] == tp.erc_token_id:
                    #if n < tp.place:
                    #    dontinsert = True
                    sorted_rating.pop(n)
            if not dontinsert:
                sorted_rating.insert(
                    tp.place,
                    {
                        "token": tp.erc_token.address,
                        "change": change_percent,
                        "buys_amount": len(token_buys),
                        "volume": sum([tb.usd_amount for tb in token_buys]),
                        "new_buyers": unique_buyers,
                        "total_buyers": len(token_buys)
                    }
                )
        except Exception as e:
            print(e)
            continue
 #   for r in sorted_rating:
  #      print(r)
    resp = await compose_template(db, sorted_rating, old_trenders)

    settings: GlobalSettings = await db.get(GlobalSettings)
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text='🤑 Buy a Spot',
                    url=f'https://t.me/{(await bot.get_me()).username}?start=solbuy'
                )
            ]
        ]
    )
    if not settings.trending_message_id:
        m = await bot.send_message(bot_config.trending_id, text=resp, reply_markup=kb, disable_web_page_preview=True)
        await db.update(GlobalSettings, trending_message_id=m.message_id)
    else:
        await bot.edit_message_text(
            chat_id=bot_config.trending_id,
            message_id=settings.trending_message_id,
            text=resp,
            disable_web_page_preview=True,
            reply_markup=kb
        )


async def compose_template(db: Client, sorted_rating: list[dict], old_trenders: List[Token]):
    EMOJI_NUMBERS = {
        0: "0️⃣",
        1: "🥇",
        2: "🥈",
        3: "🥉",
        4: "4️⃣",
        5: "5️⃣",
        6: "6️⃣",
        7: "7️⃣",
        8: "8️⃣",
        9: "9️⃣",
        10: "🔟"
    }

    rating_msg = "🪙 @SOL_TRENDING | SOLANA Trending 🪙\n"
    for n, data in enumerate(sorted_rating, start=1):
        if n not in EMOJI_NUMBERS:
            break
        token: Token = await db.get(Token, key={'address': data["token"]})
        birdlink = f'https://birdeye.so/token/{token.address}?chain=solana'
        group: GroupSettings = await db.get(GroupSettings, key={'token_address': token.address})
        if group:
            tglink = group.tg_group
        else:
            tglink = ''
        prc = format(abs(data["change"]), ".2f")
        if token.address not in old_trenders:
            entered_msg = '<b>🚀📈 TRENDING ALERT! 📈🚀</b>' \
                          f'\n\n🌐 <a href="{group.tg_group if group else ""}">{emojize(token.name)}</a> just entered @SOL_TRENDING!' \
                          f'\n\n🪙 Token: <a href="https://solscan.io/token/{token.address}">{token.address}</a>' \
                          f'\n📊 Position: #{n}'
            m = await bot.send_message(chat_id=bot_config.alerts_id, text=entered_msg, disable_web_page_preview=True)
#            print(m)
            await bot.send_message(chat_id=bot_config.admins[0], text=entered_msg, disable_web_page_preview=True,)
        await db.update(Token, key={'address': token.address}, trending_place=n)
        change = f"⬆️ %{prc}" if float(data['change']) > 0 else f"⬇️ %{prc}"
        rating_msg += f'\n{EMOJI_NUMBERS[n]} <b><a href="{tglink}">{emojize(token.name)}</a></b> ' \
                      f'|<i><a href="{birdlink}"> ${int(data["volume"]):,} {change}</a></i> ' \
                      f'| {data["total_buyers"]} buys, {data["new_buyers"]} new buyers'
    utc_now = datetime.datetime.utcnow()
    rating_msg += f'\n\n<i>👀 Powered by @FireBuy_bot to qualify use Birdy buy bot in your group\n\nLast update: {utc_now.date()} {utc_now.time()} UTC</i>'
    return rating_msg


async def upd():
    while True:
        db = get_db()
        try:
            await update_trending(db)
            await asyncio.sleep(60 * 15)
        except Exception as e:
            print(e)
            continue

if __name__ == '__main__':
    asyncio.run(upd())
