import asyncio
import datetime
from contextlib import suppress
from typing import List

import aiohttp
from aiogram.fsm.storage.base import StorageKey

from database import Client
from database.models import Order, ERCTrendingPlace, TonTrendingPlace, SolTrendingPlace
from loader import get_db, NOWPAYMENTS_KEY, bot, plate, dp
from states import BuyState


async def checking_loop():
    db = get_db()
    statuses = [
        'waiting',
        'confirming',
        'confirmed',
        'sending',
        'partially_paid',
    ]
    while True:
        for st in statuses:
            orders: List[Order] = await db.get(Order, key={'status': st}, get_type='scalars')
#            orders: List[Order] = await db.get(Order, key={'id': 550}, get_type='scalars')
            for o in orders:
                if False:#o.created_at + datetime.timedelta(hours=1) < datetime.datetime.now() and o.status == 'waiting':
                    with suppress(Exception):
                        await bot.send_message(
                            chat_id=o.user_id,
                            text=f'⚠️<b> Your order #{o.id} for {o.erc_token.name} has expired.</b>'
                        )
                    print(f'updating {o.id} to expired')
                    await db.update(Order, key={'id': o.id}, status='expired')
                    continue
                try:
                    await _check(db, o)
                except Exception as e:
                    print('issue: ' + str(e))
                    continue
        await asyncio.sleep(60)


async def _check(db: Client, order: Order):
    url = f"https://api.nowpayments.io/v1/payment/{order.payment_id}"

    payload = {}
    headers = {
        'x-api-key': NOWPAYMENTS_KEY
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers, data=payload) as r:
            try:
                data = await r.json()
                #print(data)
                await parse(db, data)
            except Exception as e:
                print(f'{order}\n\n: {e} :\n\n{data}')
                pass


async def parse(db: Client, data: dict):
    payment_id = data['payment_id']
    order_id = data['order_id']
    status = data['payment_status']
    pay_currency = data['pay_currency']
    had_to_pay = data['pay_amount']
    actually_paid = data['actually_paid']
    o: Order = await db.get(Order, key={'id': order_id})
    if status == 'expired':
        """with suppress(Exception):
            await bot.send_message(
                chat_id=o.user_id,
                text=f'⚠️<b> Your order #{o.id} for {o.token.name} has expired.</b>'
            )"""
        print(f'updating {o.id} to expired')
        await db.update(Order, key={'id': o.id}, status='expired')

    await db.update(
        Order,
        key={'id': order_id},
        payment_id=payment_id,
        #status=status,
        pay_currency=pay_currency,
        had_to_pay=had_to_pay,
        actually_paid=actually_paid
    )
    _order: Order = await db.get(Order, key={'id': order_id})

    if status in ['finished', 'sending']:
        now = datetime.datetime.now()
        if _order.blockchain == 'ton':
            something_active = await db.get(TonTrendingPlace, key={'place': _order.place, 'is_active': True})
            await db.insert(
                TonTrendingPlace,
                place=_order.place,
                token_address=_order.ton_token_address,
                until=None if something_active else now + datetime.timedelta(hours=_order.hours),
                is_active=False if something_active else True
            )
            token_name = _order.ton_token.name
            #await db.update(GroupSettings, key={'ton_token_address': _order.ton_token_address}, tg_group=_order.tg_group)
        elif _order.blockchain == 'sol':
            something_active = await db.get(SolTrendingPlace, key={'place': _order.place, 'is_active': True})
            await db.insert(
                SolTrendingPlace,
                place=_order.place,
                token_address=_order.sol_token_address,
                until=None if something_active else now + datetime.timedelta(hours=_order.hours),
                is_active=False if something_active else True
            )
            token_name = _order.sol_token.name
        else:
            something_active = await db.get(ERCTrendingPlace, key={'place': _order.place, 'is_active': True})
            await db.insert(
                ERCTrendingPlace,
                place=_order.place,
                erc_token_id=_order.erc_token_id,
                until=None if something_active else now + datetime.timedelta(hours=_order.hours),
                is_active=False if something_active else True
            )
            token_name = _order.erctoken.name

            #await db.update(GroupSettings, key={'token_address': _order.token_address}, tg_group=_order.tg_group)
        try:
            await bot.send_message(
                chat_id=_order.user_id,
                text=f'✅ We have received payment for your order #{order_id} - {token_name}'
            )
        except Exception as e:
            print(e)
        _order: Order = await db.update(Order, key={'id': order_id}, status='finished')
        key = StorageKey(
            bot_id=bot.id,
            user_id=_order.user_id
        )
        await dp.storage.set_state(bot, key=key, state=BuyState.tg_group)
        await dp.storage.update_data(bot, key=key, data={'order_id': _order.id})
        await bot.send_message(chat_id=_order.user_id, text=plate('buy_trending_tg_group'))


if __name__ == '__main__':
    asyncio.run(checking_loop())
#    order_ids = [8, 10]
#    asyncio.run(manual_push(order_ids))

