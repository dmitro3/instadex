import asyncio
from typing import List

from emoji import demojize

from database import Client
from database.models import GroupSettings
from loader import get_db, bot


async def checking_loop(db: Client):
    groups: List[GroupSettings] = await db.get(GroupSettings, get_type='scalars')
    for g in groups:
        try:
            chat = await bot.get_chat(g.id)
            members = await bot.get_chat_member_count(g.id)
            await db.update(GroupSettings, key={'id': g.id}, members_count=members, title=demojize(chat.title))
            print(members)
        except Exception as e:
            #await db.delete(GroupSettings, key={'id': g.id})
            pass


async def upd():
    while True:
        db = get_db()
        try:
            await checking_loop(db)
            await asyncio.sleep(60 * 60)
        except Exception as e:
            print(e)
            continue

if __name__ == '__main__':
    asyncio.run(upd())