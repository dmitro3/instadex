import asyncio
import datetime
from typing import List

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from emoji import emojize

from database import Client
from database.models import ERCToken, GroupSettings, Buy, GlobalSettings, ERCTrendingPlace, Order, Blockchain
from loader import bot, get_db
from config import bot_config


async def update_trending(db: Client):
    hour_ago = datetime.datetime.now() - datetime.timedelta(hours=1)
    shortname = 'ethereum'
    buys: List[Buy] = await db.get(Buy, key={'blockchain': shortname}, get_type='scalars', where=Buy.created_at > hour_ago)
    tokens_in_buys = set([b.token_address for b in buys])


    blockchain: Blockchain = await db.get(Blockchain, key={'shortname': shortname})

    rating = []
    for t in tokens_in_buys:
        token_buys = await db.get(Buy, key={'token_address': t, 'blockchain': blockchain.shortname}, get_type='scalars', where=Buy.created_at > hour_ago)
        print(token_buys)
        change_percent = ((float(token_buys[-1].price) - float(token_buys[0].price)) / float(token_buys[0].price)) * 100
        token: ERCToken = await db.get(ERCToken, key={'address': t, 'blockchain_id': blockchain.id})
        if not token:
            continue
        if change_percent < 0:
            pass
        unique_buyers = len([i for i in token_buys if 'NEW!' in i.printable_position])
        rating.append({
            "token": token.address,
            "change": change_percent,
            "buys_amount": len(token_buys),
            "volume": sum([tb.usd_amount for tb in token_buys]),
            "new_buyers": unique_buyers,
            "total_buyers": len(token_buys)
        })

    sorted_rating = sorted(rating, key=lambda x: x['volume'], reverse=True)[:14]
    old_trenders: List[ERCToken] = [
        i.address for i in await db.get(ERCToken, key={'blockchain_id': blockchain.id}, where=ERCToken.trending_place is not None, get_type='scalars') if i.trending_place
    ]
    await db.update(ERCToken, trending_place=None)
    trending_places: List[ERCTrendingPlace] = await db.get(ERCTrendingPlace, key={'is_active': True, 'blockchain_id': blockchain.id}, get_type='scalars', order_by=ERCTrendingPlace.place)
    for tp in trending_places:
        if tp.until and tp.until < datetime.datetime.now():
            next_in_line: ERCTrendingPlace = await db.get(
                ERCTrendingPlace,
                key={'place': tp.place, 'is_active': False, 'blockchain_id': blockchain.id},
                order_by=ERCTrendingPlace.created_at
            )
            await db.delete(ERCTrendingPlace, key={'id': tp.id, 'blockchain_id': blockchain.id})
            if not next_in_line:
                continue
            _order = await db.get(Order, key={'erctoken_id': next_in_line.erc_token_id})
            await db.update(ERCTrendingPlace, key={'id': next_in_line.id, 'blockchain_id': blockchain.id}, is_active=True, until=datetime.datetime.now() + datetime.timedelta(hours=_order.hours))
            tp = next_in_line
            if not tp:
                continue
        token_buys = await db.get(Buy, key={'token_address': tp.erc_token.address, 'blockchain': blockchain.shortname}, get_type='scalars', where=Buy.created_at > hour_ago)
        dontinsert = False
        try:
            change_percent = ((float(token_buys[-1].price) - float(token_buys[0].price)) / float(
                token_buys[0].price)) * 100
            unique_buyers = len([i for i in token_buys if 'NEW!' in i.printable_position])
            print(f'Inserting {tp.erc_token} to #{tp.place}')
            s = sorted_rating.copy()
            for n, data in enumerate(s):
                # this part checks if token that is paid for trending is already in the list and is in the place above that he paid for
                if data['token'] == tp.erc_token_id:
                    #if n < tp.place:
                    #    dontinsert = True
                    sorted_rating.pop(n)
            if not dontinsert:
                sorted_rating.insert(
                    tp.place,
                    {
                        "token": tp.erc_token.address,
                        "change": change_percent,
                        "buys_amount": len(token_buys),
                        "volume": sum([tb.usd_amount for tb in token_buys]),
                        "new_buyers": unique_buyers,
                        "total_buyers": len(token_buys)
                    }
                )
        except Exception as e:
            print(e)
            continue
 #   for r in sorted_rating:
  #      print(r)
    resp = await compose_template(db, blockchain, sorted_rating, old_trenders)

    settings: GlobalSettings = await db.get(GlobalSettings)
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text='🤑 Buy a Spot',
                    url=f'https://t.me/{(await bot.get_me()).username}?start=buy{shortname}'
                )
            ]
        ]
    )
    if not blockchain.trending_message_id:
        m = await bot.send_message(blockchain.trending_channel_id, text=resp, reply_markup=kb, disable_web_page_preview=True)
        await db.update(Blockchain, key={'id': blockchain.id}, trending_message_id=m.message_id)
    else:
        try:
            await bot.edit_message_text(
                chat_id=blockchain.trending_channel_id,
                message_id=blockchain.trending_message_id,
                text=resp,
                disable_web_page_preview=True,
                reply_markup=kb
            )
        except Exception:
            m = await bot.send_message(blockchain.trending_channel_id, text=resp, reply_markup=kb,
                                       disable_web_page_preview=True)
            await db.update(Blockchain, key={'id': blockchain.id}, trending_message_id=m.message_id)
            await bot.pin_chat_message(blockchain.trending_channel_id, message_id=m.message_id)


async def compose_template(db: Client, blockchain: Blockchain, sorted_rating: list[dict], old_trenders: List[ERCToken]):
    EMOJI_NUMBERS = {
        0: "0️⃣",
        1: "🥇",
        2: "🥈",
        3: "🥉",
        4: "4️⃣",
        5: "5️⃣",
        6: "6️⃣",
        7: "7️⃣",
        8: "8️⃣",
        9: "9️⃣",
        10: "🔟"
    }

    rating_msg = f"🪙 @{blockchain.trending_channel_username} | {blockchain.name.upper()} Trending 🪙\n"
    for n, data in enumerate(sorted_rating, start=1):
        if n not in EMOJI_NUMBERS:
            break
        token: ERCToken = await db.get(ERCToken, key={'address': data["token"], 'blockchain_id': blockchain.id})
        birdlink = f'https://dexscreener.com/{blockchain.shortname}/{token.pair_address}'
        group: GroupSettings = await db.get(GroupSettings, key={'erctoken_id': token.id})
        if group and group.username:
            tglink = f't.me/{group.username}'
        else:
            tglink = ''
        prc = format(abs(data["change"]), ".2f")
        """if token.address not in old_trenders:
            entered_msg = '<b>🚀📈 TRENDING ALERT! 📈🚀</b>' \
                          f'\n\n🌐 <a href="{group.tg_group if group else ""}">{emojize(token.name)}</a> just entered @SOL_TRENDING!' \
                          f'\n\n🪙 Token: <a href="https://solscan.io/token/{token.address}">{token.address}</a>' \
                          f'\n📊 Position: #{n}'
            m = await bot.send_message(chat_id=bot_config.alerts_id, text=entered_msg, disable_web_page_preview=True)
#            print(m)
            await bot.send_message(chat_id=bot_config.admins[0], text=entered_msg, disable_web_page_preview=True,)"""
        await db.update(ERCToken, key={'address': token.address}, trending_place=n)
        change = f"⬆️ %{prc}" if float(data['change']) > 0 else f"⬇️ %{prc}"
        rating_msg += f'\n{EMOJI_NUMBERS[n]} <b><a href="{tglink}">{emojize(token.name)}</a></b> ' \
                      f'|<i><a href="{birdlink}"> ${int(data["volume"]):,} {change}</a></i> ' \
                      f'| {data["buys_amount"]} buys, {data["new_buyers"]} new buyers'
    utc_now = datetime.datetime.utcnow()
    rating_msg += f'\n\n<i>👀 Powered by @FireBuy_bot to qualify use Fire buy bot in your group\n\nLast update: {utc_now.date()} {utc_now.time()} UTC</i>'
    return rating_msg


async def upd():
    while True:
        db = get_db()
        try:
            await update_trending(db)
            await asyncio.sleep(60 * 15)
        except Exception as e:
            print(e)
            continue

if __name__ == '__main__':
    asyncio.run(upd())
