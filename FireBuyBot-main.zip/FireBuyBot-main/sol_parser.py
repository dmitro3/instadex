import math
import time
from typing import List

import json

from multiprocessing import Process, Queue

import requests
from emoji import demojize
from solana.rpc.api import Client
from solders.pubkey import Pubkey

from database.models import Buy, SolTransaction, SolToken, GlobalSettings

from loader import get_db


class TransactionParser(Client):
    def __init__(self, url):
        super().__init__(url)
        self.url = url
        self.SOL = 'So11111111111111111111111111111111111111112'
        self.USDC = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'
        self.USDT = 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB'
        self.HELIUS_KEY = ''
        self.RAYDIUM_V4 = '5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j1'
        self.post_queue = Queue()
        self.queue = Queue()

    def set_db(self):
        self.db = get_db()

    def get_token_balance(self, token_account_address):
        balance = json.loads(
            self.get_token_account_balance(Pubkey.from_string(token_account_address)).to_json()
        )
        return balance['result']['value']['amount']

    def check_whale(self, signer: str):
        sol_balance = json.loads(
            self.get_balance(Pubkey.from_string(signer)).to_json()
        )
        return sol_balance['result']['value'] * 10 ** -9 > 5000

    def load_transactions(self, txs: List[SolTransaction], tokens: List[SolToken]):
        attempt = 1
        while True:
            data = self.helius(txs)
            if not data:
                print(f'NOT DATA: {data} | attempt #{attempt}')
                attempt += 1
                time.sleep(2)
                continue
            if 'error' in data:
                print(f'error data: {data}')
                continue
            print(f'finally data! after {attempt} attempt')
            break

        for n, d in enumerate(data):
            data = d
            tx = d['signature']
            token_transfers = d['tokenTransfers']
            for transfer in token_transfers:
                if self.RAYDIUM_V4 == transfer['fromUserAccount']:
                    token = transfer['mint']
                    token_amount = transfer['tokenAmount']
                if self.RAYDIUM_V4 == transfer['toUserAccount']:
                    raydium_received_token = transfer['mint']
                    if raydium_received_token in [self.SOL, self.USDC, self.USDT]:
                        if raydium_received_token == self.SOL:
                            paid_with = 'SOL'
                        elif raydium_received_token == self.USDT:
                            paid_with = 'USDT'
                        else:
                            paid_with = 'USDC'
                        paid_amount = transfer['tokenAmount']
            #print(f'Raydium sent {raydium_sent} of {raydium_sent_token} and got {paid_amount} of {raydium_received_token}')
            tx = self.db.sync_get(SolTransaction, key={'tx_hash': tx})
            if not tx:
                #print('not tx')
                return

            signer = data['feePayer']
            transfers = data['tokenTransfers']
            tokens_in_tx = [i['mint'] for i in transfers]

            signer_got_something = False
            for t in transfers:
                #token_amount = t['tokenAmount']
                #token = t['mint']
                _from = t['fromUserAccount']
                _to = t['toUserAccount']
                _from_token = t['fromTokenAccount']
                _to_token = t['toTokenAccount']
                # print(token_amount, _to, signer, token)
                if _from == signer and token in [self.SOL, self.USDC, self.USDT]:
                    if token == self.SOL:
                        paid_with = 'SOL'
                    elif token == self.USDT:
                        paid_with = 'USDT'
                    else:
                        paid_with = 'USDC'
                    #paid_amount = token_amount
                if _to == signer and token not in [self.SOL, self.USDC, self.USDT]:
                    signer_got_something = True

            if not signer_got_something:
                #print(f'Signer got nothing: {tx.tx_hash}')
                self.db.sync_delete(SolTransaction, key={'id': tx.id})
                continue
            if not paid_with or not paid_amount:
                #print(f'Paid with or token amount is None/0: {tx.tx_hash}')
                self.db.sync_delete(SolTransaction, key={'id': tx.id})
                continue
            bad_tx = False
            for t in tokens:
                if t in tokens_in_tx:
                    #print('token in token list')
                    bad_tx = False
                    break
            if transfers[-1]['mint'] in [self.SOL, self.USDC, self.USDT]:
                #print('is sell')
                self.db.sync_delete(SolTransaction, key={'id': tx.id})
                continue
            if bad_tx:
                #print(f'bad tx: {tx.tx_hash}')
                self.db.sync_delete(SolTransaction, key={'id': tx.id})
                continue
            if token in [self.SOL, self.USDC, self.USDT]:
                #print(f'token is sol/stables tx: {tx.tx_hash}')
                self.db.sync_delete(SolTransaction, key={'id': tx.id})
                continue
            token: SolToken = self.db.sync_get(SolToken, key={'address': token})
            if not token:
                #print(f'1: not token: {tx.tx_hash}')
                self.db.sync_delete(SolTransaction, key={'id': tx.id})
                continue
            data_dict = {
                "token": token.address,
                "paid_with": paid_with,
                "paid_amount": paid_amount,
                "token_amount": token_amount,
                "_to_token": _to_token,
                "signer": signer
            }
#            print(f'putting: {tx}')
            self.post_queue.put((data_dict, tx))
            self.db.sync_delete(SolTransaction, key={'id': tx.id})
#        print('finished parsing ')

    def helius(self, txs: List[SolTransaction]):
        url = f"https://api.helius.xyz/v0/transactions/?api-key={self.HELIUS_KEY}"
        headers = {
            'Content-Type': 'application/json',
        }
        body = json.dumps({
            'transactions': [tx.tx_hash for tx in txs],
        })
        with requests.post(url, headers=headers, data=body) as response:
            data = response.json()
            return data


    def parse_transaction(self, data_dict, tx):
        token = data_dict['token']
        paid_with = data_dict['paid_with']
        paid_amount = data_dict['paid_amount']
        token_amount = data_dict['token_amount']
        _to_token = data_dict['_to_token']
        signer = data_dict['signer']
        if isinstance(token, str):
            token: SolToken = self.db.sync_get(SolToken, key={'address': token})
        if not token:
            #print(f'not token: {token}')
            self.db.sync_delete(SolTransaction, key={'id': tx.id})
            return
        settings: GlobalSettings = self.db.sync_get(GlobalSettings)
        usd_amount = paid_amount * settings.sol_price if paid_with == 'SOL' else paid_amount

        price = usd_amount / token_amount
        market_cap = int(token.supply) * price * 10 ** -token.decimals

        try:
            holdings = float(self.get_token_balance(_to_token)) * 10 ** -token.decimals
        except Exception as e:
            #print('holding+ ', e)
            """self.db.sync_delete(SolTransaction, key={'id': tx.id})
            return"""
            holdings = 0

        if holdings <= 0:
            printable_position = "NEW!"
        else:
            percent = round(((float(token_amount) / float(holdings)) * 100), 2)
            if int(percent) > 1000:
                printable_position = 'over 1000%'
            else:
                printable_position = f'🆙 {str(percent)}%'
                """if printable_position == '🆙 0.0%':
                    print(f'Bad printable: {tx.tx_hash}')
                    self.db.sync_delete(SolTransaction, key={'id': tx.id})
                    return"""

        try:
            self.db.sync_insert(
                Buy,
                token_address=token.address,
                tx_hash=tx.tx_hash,
                signer=signer,
                usd_amount=self.truncate(usd_amount, 5),
                paid_amount=float(format(paid_amount, ".5f")),
                paid_with=paid_with,
                token_amount=self.truncate(token_amount, 2),
                market_cap=market_cap,
                price=price,
                printable_position=demojize(printable_position),
            )
        except Exception as e:
            #print('inserting ', e)
            pass
        self.db.sync_delete(SolTransaction, key={'id': tx.id})

    def zero_amt(self, n, q=0):
        if n >= 1:
            return q - 1
        n = n * 10
        return self.zero_amt(n, q + 1)

    def truncate(self, f, n):
        result = math.floor(f * 10 ** n) / 10 ** n
        if result <= 0:
            result = self.truncate(f, 5)
        return result

    def format_price(self, price):
        # Mapping of digits to their subscript counterparts
        zeroes = self.zero_amt(price)
        exponent_price = str(self.truncate(price, zeroes + 4) * (10 ** zeroes))
        SUB = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")
        new_price = exponent_price[exponent_price.index(".") + 1:exponent_price.index(".") + 5]
        price = f'0.0{str(zeroes).translate(SUB)}{new_price}'
        return price

    def run(self):
        print('Starting...')
        self.set_db()
        producer = Process(target=self.check_transactions, daemon=True)
        for i in range(20):
            consumer = Process(target=self.get_transactions, daemon=True, args=(i,))
            consumer.start()
        for i in range(20):
            poster = Process(target=self.parse_transactions, daemon=True, args=(i,))
            poster.start()

        producer.start()

        while True:
            pass

    """def consumer_worker(self, consumer_id: int):
        while True:
            try:
                self.get_transactions(consumer_id)
            except Exception as e:
                print(f'Consumer #{consumer_id} encountered an error: {e}')
                continue

    def parser_worker(self, parser_id: int):
        while True:
            try:
                self.parse_transactions(parser_id)
            except Exception as e:
                print(f'Parser #{parser_id} encountered an error: {e}')
                continue"""

    def check_transactions(self):
        print('Producer started')
        while True:
            transactions: List[SolTransaction] = self.db.sync_get(
                SolTransaction,
                key={'in_processing': False},
                get_type='scalars',
                limit=100
            )
            tokens: List[SolToken] = self.db.sync_get(SolToken, get_type='scalars')
            if len(transactions) < 100:
                continue
            self.queue.put((transactions, tokens))
            for t in transactions:
                self.db.sync_update(SolTransaction, key={'id': t.id}, in_processing=True)

    def get_transactions(self, consumer_id: int):
        print(f'Consumer #{consumer_id} started.')
        while True:
            transactions, tokens = self.queue.get()
            print(f'Consumer #{consumer_id} took {len(transactions)} transactions')
            try:
                self.load_transactions(transactions, tokens)
            except Exception as e:
                print(e)
                continue

    def parse_transactions(self, consumer_id: int):
        print(f'Parser #{consumer_id} started.')
        while True:
            data_dict, tx = self.post_queue.get()
            try:
                self.parse_transaction(data_dict, tx)
            except Exception as e:
                print(e)
                continue


if __name__ == '__main__':
    parser = TransactionParser('https://api.mainnet-beta.solana.com')
#    parser = TransactionParser('https://mainnet.helius-rpc.com/?api-key=9c82f190-6987-4ee8-a1c3-db5978dffe08')
    """tx_hashes = [
        '2Byxb68zLXW2XJnzRhApWn89KLR6QSJLBbnF9K3CPjEfzS9m4WYoEVhx3QYxShNY4TfDsAKU5FTzAxP1spYQj3tB'
    ]
    asyncio.run(parser._test_check(tx_hashes))"""
    parser.run()


