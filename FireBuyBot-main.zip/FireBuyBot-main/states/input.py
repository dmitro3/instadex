from aiogram.fsm.state import State, StatesGroup


class InputState(StatesGroup):
    select_blockchain = State()
    select_type = State()
    set_presale_pool = State()

    set_token = State()
    set_name = State()
    set_symbol = State()
    set_supply = State()
    set_decimals = State()

    blockchain = State()
    pair = State()
    minimum_buy = State()
    step = State()
    custom_supply = State()
    emoji = State()
    media = State()
    media_threshold = State()
    tg_group = State()

    new_ad_text = State()
    new_ad_url = State()

