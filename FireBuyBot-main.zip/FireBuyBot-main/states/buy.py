from aiogram.fsm.state import State, StatesGroup


class BuyState(StatesGroup):
    presale_pool = State()
    token = State()
    tg_group = State()
    spot = State()
    hours = State()
    confirm = State()